import pytest


def test_failure_reset_clears_selection_and_restores_baseline():
    from pathlib import Path
    from streamlit.testing.v1 import AppTest
    app = AppTest.from_file(
        Path(__file__).resolve().parents[1] / 'src/floodcut/app.py',
        default_timeout=30,
    ).run()
    app.sidebar.radio[1].set_value('Failure Simulation').run()
    assert not app.exception
    selection = app.multiselect[0]
    selection.set_value([selection.options[0]]).run()
    assert not app.exception
    next(b for b in app.button if b.label == 'Reset all simulated failures').click().run()
    assert not app.exception
    assert app.multiselect[0].value == []
    assert any(m.label == 'Base Deliverable Flow' for m in app.metric)

from floodcut.failure import FailureSimError, apply_failure_percentages
from floodcut.repair import RepairOptError, _candidate_drains, apply_condition_percentages


def test_partial_failure_uses_current_effective_capacity(sim_network):
    network = sim_network
    did = next(iter(network.drains))
    original = network.drains[did]
    changed = apply_failure_percentages(network, {did: 25})
    assert changed.drains[did].effective_capacity_m3s == pytest.approx(
        original.effective_capacity_m3s * 0.75
    )
    assert network.drains[did] is original


@pytest.mark.parametrize("percentage, remaining", [(0, 1.0), (50, 0.5), (100, 0.0)])
def test_failure_percentage_endpoints(sim_network, percentage, remaining):
    network = sim_network
    did = next(iter(network.drains))
    changed = apply_failure_percentages(network, {did: percentage})
    assert changed.drains[did].capacity_factor == pytest.approx(
        network.drains[did].capacity_factor * remaining
    )


@pytest.mark.parametrize("percentage", [-1, 101, float("nan")])
def test_failure_percentage_rejects_invalid_values(sim_network, percentage):
    network = sim_network
    did = next(iter(network.drains))
    with pytest.raises(FailureSimError):
        apply_failure_percentages(network, {did: percentage})


def test_condition_can_make_previously_healthy_drain_a_candidate(sim_network):
    network = sim_network
    did = next(d.id for d in network.drains.values() if d.capacity_factor == 1.0)
    changed = apply_condition_percentages(network, {did: 40})
    assert changed.drains[did].capacity_factor == pytest.approx(0.4)
    assert did in _candidate_drains(changed)


def test_condition_can_reset_individual_drain_to_healthy(sim_network):
    network = sim_network
    did = next(d.id for d in network.drains.values() if d.capacity_factor < 1.0)
    changed = apply_condition_percentages(network, {did: 100})
    assert changed.drains[did].capacity_factor == 1.0
    assert did not in _candidate_drains(changed)


@pytest.mark.parametrize("percentage", [-0.1, 100.1, float("inf")])
def test_condition_percentage_rejects_invalid_values(sim_network, percentage):
    network = sim_network
    did = next(iter(network.drains))
    with pytest.raises(RepairOptError):
        apply_condition_percentages(network, {did: percentage})
