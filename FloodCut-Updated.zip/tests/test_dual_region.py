from datetime import datetime, timezone
import pytest
from floodcut import rheden, knmi


def mh(guid, coords=None):
    return {'properties': {'OBJECT_GUID':guid}, 'geometry': {'type':'Point', 'coordinates':coords or [6,52]}}


def pipe(oid, a, b):
    return {'properties': {'OBJECTID':oid, 'ID':f'original-{oid}', 'BEGINPUT_ID':a, 'EINDPUT_ID':b},
            'geometry': {'type':'LineString', 'coordinates':[[6,52],[6.1,52.1]]}}


def fixture_network():
    return rheden.build_network([pipe(1,'a','b'),pipe(2,'a','b'),pipe(3,'b','c'),pipe(4,'c','d'),pipe(5,'d','missing')], [mh(x) for x in 'abcd'])


def test_exact_join_parallel_edges_and_unresolved():
    n = fixture_network()
    assert len(n.pipes) == 5 and n.graph.number_of_edges() == 4
    assert n.unresolved == ['5']
    assert n.pipes['1']['properties']['ID'] == 'original-1'
    assert rheden.summary(n.graph)['components'] == 1
    duplicate = rheden.build_network([pipe(1,'a','b')], [mh('a'),mh('a'),mh('b')])
    assert duplicate.unresolved == ['1'] and duplicate.duplicate_manhole_ids == {'a'}


def test_structural_bridges_articulation_and_multiple_failures():
    n = fixture_network()
    bridges, points = rheden.structural_analysis(n.graph)
    assert bridges == {'3','4'} and points == {'b','c'}
    after, separated = rheden.simulate_failure(n.graph, ['3','4'])
    assert rheden.summary(after)['components'] == 3
    assert separated == {'c','d'}
    assert n.graph.number_of_edges() == 4
    with pytest.raises(ValueError): rheden.simulate_failure(n.graph, ['5'])


def test_knmi_missing_trace_and_hour_24():
    text = '# STN,YYYYMMDD,HH,RH\n275,20240101,23,-1\n275,20240101,24, 4\n275,20240102,1,\n'
    start=datetime(2024,1,1,23,tzinfo=timezone.utc); end=datetime(2024,1,2,2,tzinfo=timezone.utc)
    rows=knmi.parse_hourly(text,start,end)
    assert rows[0]['trace'] and rows[0]['rain_mm'] is None and not rows[0]['missing']
    assert rows[1]['rain_mm'] == .4
    assert rows[2]['missing'] and rows[3]['missing']


def test_fetch_detects_incomplete_batches(monkeypatch):
    def query(service, params):
        return {'objectIds':[1,2]} if params.get('returnIdsOnly') else {'features':[pipe(1,'a','b')]}
    monkeypatch.setattr(rheden,'_query',query)
    with pytest.raises(RuntimeError, match='Incomplete'): rheden.fetch_layer('pipes')


def test_import_reconciliation_accounts_for_missing_endpoints():
    manholes = [mh(x) for x in 'abcd']
    pipes = [
        pipe(1, 'a', 'b'),
        pipe(2, None, 'b'),
        pipe(3, 'c', None),
        pipe(4, None, None),
    ]
    net = rheden.build_network(pipes, manholes)
    audit = rheden.reconcile_import(pipes, manholes, net)
    assert audit.original_pipe_records == 4
    assert audit.valid_pipe_geometries == 4
    assert audit.graph_edges_created == 1
    assert audit.unrepresented_pipe_geometries == 3
    assert audit.missing_endpoint_reference_slots == 4
    assert audit.endpoint_pair_counts == {
        'matched -> matched': 1,
        'matched -> missing': 1,
        'missing -> matched': 1,
        'missing -> missing': 1,
    }


def test_exact_duplicate_geometries_are_reported_but_not_merged():
    pipes = [pipe(1, 'a', 'b'), pipe(2, 'a', 'b')]
    manholes = [mh('a'), mh('b')]
    net = rheden.build_network(pipes, manholes)
    audit = rheden.reconcile_import(pipes, manholes, net)
    assert net.graph.number_of_edges() == 2
    assert set(k for _, _, k in net.graph.edges(keys=True)) == {'1', '2'}
    assert audit.duplicate_geometry_groups == 1
    assert audit.duplicate_geometry_records == 2
    assert audit.duplicate_geometry_excess_records == 1


def test_multiline_record_creates_one_edge_without_geometry_splitting():
    feature = pipe(1, 'a', 'b')
    feature['geometry'] = {
        'type': 'MultiLineString',
        'coordinates': [[[6, 52], [6.05, 52.05]], [[6.05, 52.05], [6.1, 52.1]]],
    }
    net = rheden.build_network([feature], [mh('a'), mh('b')])
    assert len(net.pipes) == 1
    assert net.graph.number_of_edges() == 1


def test_geometry_coincidence_does_not_replace_missing_source_id():
    feature = pipe(1, None, 'b')
    feature['geometry']['coordinates'][0] = [6, 52]
    net = rheden.build_network([feature], [mh('a', [6, 52]), mh('b', [6.1, 52.1])])
    assert net.unresolved == ['1']
    assert net.graph.number_of_edges() == 0


def test_colocated_distinct_manhole_ids_remain_separate_components():
    manholes = [
        mh('a', [6, 52]), mh('b', [6.1, 52.1]),
        mh('c', [6.1, 52.1]), mh('d', [6.2, 52.2]),
    ]
    net = rheden.build_network([pipe(1, 'a', 'b'), pipe(2, 'c', 'd')], manholes)
    assert rheden.summary(net.graph)['components'] == 2


@pytest.mark.parametrize(
    ('geometry', 'reason'),
    [
        ({'type': 'Point', 'coordinates': [6, 52]}, 'unsupported_geometry_type'),
        ({'type': 'LineString', 'coordinates': []}, 'empty_or_short_part'),
        ({'type': 'LineString', 'coordinates': [[6, 52], ['bad', 52]]}, 'invalid_coordinate'),
    ],
)
def test_rejected_pipe_geometry_reason_codes(geometry, reason):
    feature = pipe(1, 'a', 'b')
    feature['geometry'] = geometry
    assert rheden.geometry_rejection_reason(feature, 'pipes') == reason
    net = rheden.build_network([feature], [mh('a'), mh('b')])
    audit = rheden.reconcile_import([feature], [mh('a'), mh('b')], net)
    assert audit.rejected_geometry_reasons == {reason: 1}
    assert audit.valid_pipe_geometries == 0


def test_region_switching_and_algorithm_gating(monkeypatch):
    from streamlit.testing.v1 import AppTest
    import floodcut.ui.rheden as ui
    fixture = fixture_network()
    monkeypatch.setattr(ui, 'load_network', lambda: fixture)
    monkeypatch.setattr(
        ui,
        'load_data',
        lambda: (list(fixture.pipes.values()), list(fixture.manholes.values())),
    )
    from pathlib import Path
    app=AppTest.from_file(Path(__file__).resolve().parents[1] / 'src/floodcut/app.py', default_timeout=30).run()
    assert not app.exception
    app.sidebar.radio[0].set_value('Rheden 🇳🇱').run()
    assert not app.exception
    assert any('Hydraulic maximum flow' in x.value for x in app.markdown)
    assert any('Rheden' in x.value for x in app.header)
    app.multiselect[0].set_value(['3', '4']).run()
    assert not app.exception
    assert any('2 manholes are in sections' in x.value for x in app.caption)
    next(b for b in app.button if b.label == 'Reset scenario').click().run()
    assert not app.exception and app.multiselect[0].value == []
    app.sidebar.radio[0].set_value('Mumbai 🇮🇳').run()
    assert not app.exception
    assert any('Mumbai' in x.value for x in app.header)
