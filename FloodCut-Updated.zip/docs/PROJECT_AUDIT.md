# FloodCut: Code Audit and Fallbacks

## Scope

This is a code-and-model audit of the supplied FloodCut repository. It checks the Python implementation, dashboard flow, bundled data labels, documented assumptions, and automated tests. It is **not** an engineering validation against measured Mumbai drainage performance.

## Changes made in this revision

1. Removed **Project Overview** and **Results & Audit** from the dashboard navigation and deleted their page functions. The dashboard now opens on Interactive Map and has four pages: Interactive Map, Rainfall Explorer, Failure Simulation, and Repair Optimization.
2. Fixed the exhaustive repair safety check. Previously, the code enumerated every possible subset merely to count feasible subsets, so the supposed limit could itself take exponential time before raising an error. It now counts with budget pruning and stops as soon as the configured limit is exceeded.
3. Added a regression test for early stopping on a 30-candidate repair problem.
4. Hardened dashboard controls for alternative scenario lists and networks with no eligible drains; made the repair-budget slider adapt to available candidate costs.
5. Changed the repair optimality-gap display from a misleading `0.0%` to `N/A` when exhaustive search is unavailable, with an explanatory warning.
6. Made the rainfall loader report why it fell back to synthetic data when the real CSV is missing or invalid, instead of swallowing every exception silently. Unexpected programming errors are no longer hidden by a blanket `except Exception`.
7. Added a visible caveat to the catchment shortfall table: catchment-level allocation can vary among valid maximum-flow solutions, while total overflow is invariant.
8. Updated the dashboard documentation to remove the deleted pages and clarify that the offline graph is a manual fallback, not automatic detection of map-tile failures.

## Existing fallbacks in the project

| Situation | Current fallback | Limitation / note |
|---|---|---|
| IMD monthly rainfall CSV is absent or invalid | Bundled synthetic rainfall fixture | The UI labels it synthetic. The reason for an invalid/missing file is now surfaced as a warning.
| `streamlit-folium` cannot be imported | Matplotlib offline drainage graph | The selected interactive-map mode falls back to the graph and shows a warning.
| OpenStreetMap tiles are blocked or there is no internet | User can manually select **Offline Graph** or **Drainage Network Schematic** | The app does not automatically detect tile failure; the interactive map basemap can be blank.
| Exhaustive repair search is too large | `compare_strategies` retains greedy and baseline strategies and omits exhaustive optimum | The dashboard now reports the optimum and optimality gap as unavailable instead of implying a zero gap.
| Automated tests | Core algorithms and bundled fixtures can run offline | The UI test module still needs its declared Streamlit/Folium/Matplotlib/Pandas dependencies installed.

## Main technical limitations / risks

### 1. It is not a real Mumbai drainage model

The bundled drainage topology, conduit capacities, condition factors, and repair costs are synthetic or modeller-assumed. The hotspot points are derived/approximate and do not establish that each point is connected to the modelled conduits. The dashboard is suitable for demonstrating algorithms, not for predicting street-level inundation or selecting actual municipal repairs.

### 2. The hydrology is a steady-state screening approximation

Runoff is computed using `Q = C × i × A / 360`. The model uses uniform intensity, omits time of concentration and storage, and does not solve hydraulic head, slope, pipe-full conditions, or backwater propagation. Maximum flow assumes flow can be routed optimally, whereas real water movement is constrained by gravity and hydraulics. Treat model flow as a best-case capacity screen, not a flood forecast.

### 3. Historical monthly rainfall is not storm intensity

The bundled IMD/OpenCity data is monthly accumulated rainfall. Converting a monthly total to a mean hourly rate cannot recover peak 15-minute/hourly monsoon intensity. The `light`, `design`, `heavy`, or `extreme` scenario values are scenario assumptions; they are not automatically inferred from the historical monthly series and are not live forecasts.

### 4. Catchment-level overflow is not uniquely determined

When multiple catchments share a downstream bottleneck, different maximum-flow solutions can deliver the same total flow while assigning the shortfall to different catchments. The total `demand − max flow` is stable; the displayed per-catchment breakdown is the allocation of this particular computed solution, not a validated map of where water will flood.

### 5. Repair selection is a combinatorial optimization problem, not ordinary additive knapsack

A drain's benefit depends on which other drains are repaired. Series repairs can have zero individual gain but positive combined gain; a static benefit-per-cost ranking can miss such interactions. The project correctly compares a marginal-gain greedy heuristic with exhaustive search on small candidate sets. Greedy is not guaranteed optimal, and exhaustive search grows exponentially.

### 6. Failure enumeration scales combinatorially

Enumerating all combinations of `k` failed drains costs approximately `C(m, k)` network analyses. The UI limits `k` to at most 3, which is reasonable for the bundled small testbed but should not be presented as scalable to a city-wide graph without further algorithmic work.

### 7. Map presentation can look more authoritative than the data

The real rainfall-grid reference point, approximate derived hotspots, and synthetic drainage conduits appear together on one map. The provenance labels and legend are essential. Keep them visible and never describe the synthetic conduits as surveyed municipal drains.

## Verification performed for this revision

- `python -m compileall -q src tests` — passed.
- `PYTHONPATH=src python -m pytest -q --ignore=tests/test_phase6_frontend.py` — **258 tests passed** in the audit environment.
- The full UI test module could not be run in this audit environment because Streamlit is not installed here and package installation was blocked by unavailable network access. Run `python -m pytest -q` in the project's Windows virtual environment, where the UI dependencies were installed, to verify all tests.
