# Rheden municipal drainage import reconciliation

Investigation date: 2026-11-09. Counts below reproduce the live Municipality
of Rheden ArcGIS layers used by FloodCut. They are a snapshot and may change if
the service data changes.

## Result

The 7,142-record difference is caused by missing municipal endpoint attributes,
not geometry rejection, duplicate removal, segment merging, or NetworkX edge
collapse. Every one of the 15,234 pipe geometries passes geometry validation and
is retained in `Network.pipes`. FloodCut creates an edge only when both source
fields, `BEGINPUT_ID` and `EINDPUT_ID`, exactly identify unique manhole records
with valid point geometry.

| Reconciliation item | Records | Treatment |
|---|---:|---|
| Original pipe records returned by ArcGIS | 15,234 | Complete snapshot verified against the source OBJECTID list |
| Valid pipe geometries | 15,234 | Retained with all original properties |
| Rejected pipe geometries | 0 | No pipe failed the current LineString/MultiLineString validation |
| Exact duplicate-geometry records | 74 in 35 groups | Retained; this is an overlapping quality flag, not a subtraction |
| Duplicate-geometry excess beyond one per group | 39 | Retained; no deduplication occurs |
| Graph edges created | 8,092 | One edge per pipe record whose two endpoint IDs match |
| Valid geometries unrepresented as graph edges | 7,142 | Retained for display/inspection but excluded from topology because at least one endpoint ID is blank |

The endpoint combinations reconcile exactly:

| `BEGINPUT_ID` status | `EINDPUT_ID` status | Pipe records | Graph edge |
|---|---|---:|---|
| Matched | Matched | 8,092 | Yes |
| Missing | Matched | 3,455 | No |
| Matched | Missing | 1,238 | No |
| Missing | Missing | 2,449 | No |
| **Total** |  | **15,234** | **8,092 edges** |

There are 9,591 blank endpoint slots across the 7,142 excluded records. No
nonblank endpoint references are unmatched, and the live manhole layer has no
duplicate `OBJECT_GUID` values. The service returned 13,857 manhole records;
all 13,857 have unique, valid point records, although only 8,010 occur as nodes
on represented pipe edges.

## Import pipeline

1. `fetch_layer()` requests the complete ArcGIS OBJECTID list.
2. It retrieves records in batches of 150 with all attributes and geometry in
   EPSG:4326. It rejects a truncated, incomplete, duplicated, or changed
   snapshot before construction.
3. `build_network()` validates manhole point geometry and excludes ambiguous
   duplicate `OBJECT_GUID` values from the join lookup.
4. Each pipe LineString or MultiLineString is validated. Invalid records are
   counted and excluded; no live record was invalid in this snapshot.
5. Each valid pipe is stored under its source `OBJECTID`. A missing or duplicate
   pipe OBJECTID is a hard error rather than a silent merge.
6. The pipe becomes one `networkx.MultiGraph` edge only when both endpoint IDs
   exist in the manhole lookup. Otherwise its OBJECTID is added to `unresolved`.

No coordinate snapping, tolerance join, geometry splitting, geometry
simplification, or endpoint inference occurs. A MultiLineString source record
creates one graph edge, not one edge per part. Parallel pipes and exact duplicate
geometries remain separate edges because the source OBJECTID is the multigraph
edge key.

## Geometry and duplicate checks

The live source contains 35 exact coordinate/type duplicate groups comprising
74 records. These do not explain the edge discrepancy: the importer preserves
them, and joined duplicate records remain distinct multigraph edges.

An exploratory spatial check of the 9,591 blank endpoint slots found nearest
manholes at these approximate distances:

| Distance to nearest manhole | Blank endpoint slots within distance |
|---|---:|
| 0.01 m | 1,613 |
| 0.1 m | 2,526 |
| 1 m | 3,203 |
| 5 m | 6,643 |
| 10 m | 8,601 |
| 25 m | 9,495 |
| 50 m | 9,582 |
| 100 m | 9,591 |

Proximity does not establish identity. At least 344 blank endpoints have tied
nearest candidates within 5 cm of the same minimum distance. A global tolerance
would therefore create ambiguous or incorrect municipal connections.

## Connected components

The 8,092 joined edges and 8,010 referenced manholes form 695 connected
components under exact municipal identifiers. The largest components contain
2,186, 1,574, 916, 218, and 215 manholes. There are 345 two-node components and
19 one-node components; the source includes 23 self-referencing pipe records.

These components are genuine components of the exact source-ID graph, but the
data does not prove that all are physically separate sewer systems. An
exploratory coordinate check found 51 pairs of differently identified manholes
from different components within approximately 1 m, including one pair within
0.1 m. Those pairs may represent distinct assets, survey offsets, crossings,
or source-data linkage issues. Distance alone cannot decide which.

## Supported corrections

The importer should continue preserving all municipal geometry and exact IDs.
The added `reconcile_import()` audit exposes rejected geometry reasons,
duplicate geometry, endpoint-status pairs, graph edge counts, and unresolved
records without changing construction.

The evidence supports these follow-ups:

1. Ask the Municipality of Rheden for a source export or relationship table
   that populates the 9,591 blank endpoint references.
2. Review the 35 exact-geometry duplicate groups by OBJECTID to determine
   whether they are distinct municipal assets or source duplicates.
3. Review close cross-component manhole pairs and the 23 self-referencing pipes
   against municipal asset metadata.
4. If a spatial repair is ever proposed, produce a separate candidate table
   with distances and ambiguity counts for municipal review. Do not alter source
   IDs or graph topology automatically.

Regression tests cover missing endpoint combinations, exact duplicate geometry
retention, one-edge-per-MultiLineString behavior, invalid geometry reason codes,
the absence of coordinate snapping, and preservation of separate components
for colocated but differently identified manholes.
