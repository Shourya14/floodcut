"""Municipal Rheden records and an explicitly structural, undirected graph.

Features are loaded from the public ArcGIS services on demand. No engineering
interpretation is assigned to pipe diameter, elevation, or endpoint order.
"""
from __future__ import annotations

from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
import json
from urllib.parse import urlencode
from urllib.request import urlopen
import networkx as nx

BASE = 'https://services3.arcgis.com/zi6uvGhzrY8amIBi/arcgis/rest/services/'
SERVICES = {'pipes': 'GB_Vrijv_leiding', 'manholes': 'GB_Rioolput'}


def _query(service, params):
    url = f'{BASE}{service}/FeatureServer/0/query?' + urlencode(params)
    with urlopen(url, timeout=90) as response:
        result = json.load(response)
    if 'error' in result:
        raise RuntimeError(f"ArcGIS error: {result['error']}")
    return result


def fetch_layer(kind):
    """Fetch all IDs then all features in bounded requests; reject partial results."""
    service = SERVICES[kind]
    ids = _query(service, {'where': '1=1', 'returnIdsOnly': 'true', 'f': 'json'}).get('objectIds')
    if ids is None:
        raise RuntimeError(f'No object ID list returned for {kind}')
    def get_batch(batch):
        result = _query(service, {'objectIds': ','.join(map(str, batch)), 'outFields': '*',
                                  'outSR': 4326, 'returnGeometry': 'true', 'f': 'geojson'})
        if result.get('properties', {}).get('exceededTransferLimit'):
            raise RuntimeError(f'Truncated {kind} response')
        return result.get('features', [])
    batches = [ids[i:i + 150] for i in range(0, len(ids), 150)]
    with ThreadPoolExecutor(max_workers=4) as executor:
        features = [f for batch in executor.map(get_batch, batches) for f in batch]
    actual = [f.get('properties', {}).get('OBJECTID') for f in features]
    if len(actual) != len(ids) or set(actual) != set(ids):
        raise RuntimeError(f'Incomplete or changed {kind} snapshot: expected {len(ids)}, received {len(actual)}')
    return features


def valid_geometry(f, kind):
    return geometry_rejection_reason(f, kind) is None


def geometry_rejection_reason(f, kind):
    """Return a stable reason code, or ``None`` when geometry is accepted.

    This mirrors the import validation exactly and exists for reconciliation;
    it does not repair, snap, simplify, split or otherwise alter geometry.
    """
    g = f.get('geometry') or {}
    coords = g.get('coordinates')
    if kind == 'pipes':
        if g.get('type') == 'LineString':
            parts = [coords]
        elif g.get('type') == 'MultiLineString':
            parts = coords
        else:
            return 'unsupported_geometry_type'
        if not isinstance(parts, list) or not parts:
            return 'missing_coordinates'
        if any(not isinstance(p, list) or len(p) < 2 for p in parts):
            return 'empty_or_short_part'
        if any(not isinstance(x, list) or len(x) < 2 or
               not all(isinstance(n, (int, float)) for n in x[:2])
               for p in parts for x in p):
            return 'invalid_coordinate'
        return None
    if g.get('type') != 'Point':
        return 'unsupported_geometry_type'
    if not isinstance(coords, list) or len(coords) < 2:
        return 'missing_coordinates'
    if not all(isinstance(n, (int, float)) for n in coords[:2]):
        return 'invalid_coordinate'
    return None


@dataclass
class Network:
    pipes: dict
    manholes: dict
    graph: nx.MultiGraph
    unresolved: list
    invalid_pipes: int
    duplicate_manhole_ids: set


@dataclass(frozen=True)
class ImportReconciliation:
    """Non-mutating accounting of source records and graph construction."""
    original_pipe_records: int
    valid_pipe_geometries: int
    rejected_pipe_geometries: int
    rejected_geometry_reasons: dict
    duplicate_geometry_groups: int
    duplicate_geometry_records: int
    duplicate_geometry_excess_records: int
    graph_edges_created: int
    unrepresented_pipe_geometries: int
    endpoint_pair_counts: dict
    missing_endpoint_reference_slots: int
    source_manhole_records: int
    graph_eligible_manhole_records: int
    duplicate_manhole_ids: int


def _freeze_coordinates(value):
    if isinstance(value, list):
        return tuple(_freeze_coordinates(item) for item in value)
    return value


def reconcile_import(pipes, manholes, network=None):
    """Reconcile source records with graph edges without changing the import.

    Duplicate geometry is reported as an overlapping quality flag. Records are
    not deduplicated: OBJECTID remains the edge key. Endpoint status is based on
    exact source identifiers; spatial proximity is deliberately not a join.
    """
    network = network or build_network(pipes, manholes)
    rejected = Counter(
        reason for feature in pipes
        if (reason := geometry_rejection_reason(feature, 'pipes')) is not None
    )
    fingerprints = Counter(
        (
            feature['geometry'].get('type'),
            _freeze_coordinates(feature['geometry'].get('coordinates')),
        )
        for feature in network.pipes.values()
    )
    duplicate_sizes = [count for count in fingerprints.values() if count > 1]

    manhole_guid_counts = Counter(
        feature.get('properties', {}).get('OBJECT_GUID')
        for feature in manholes
        if feature.get('properties', {}).get('OBJECT_GUID')
    )
    valid_geometry_guids = {
        feature.get('properties', {}).get('OBJECT_GUID')
        for feature in manholes
        if feature.get('properties', {}).get('OBJECT_GUID') and
        valid_geometry(feature, 'manholes')
    }

    def endpoint_status(value):
        if value is None or value == '':
            return 'missing'
        if manhole_guid_counts[value] > 1:
            return 'duplicate_manhole_guid'
        if value not in manhole_guid_counts:
            return 'not_in_manhole_layer'
        if value not in valid_geometry_guids:
            return 'invalid_manhole_geometry'
        return 'matched'

    pairs = Counter()
    missing_slots = 0
    for feature in network.pipes.values():
        properties = feature.get('properties', {})
        start = endpoint_status(properties.get('BEGINPUT_ID'))
        end = endpoint_status(properties.get('EINDPUT_ID'))
        pairs[f'{start} -> {end}'] += 1
        missing_slots += (start == 'missing') + (end == 'missing')

    return ImportReconciliation(
        original_pipe_records=len(pipes),
        valid_pipe_geometries=len(network.pipes),
        rejected_pipe_geometries=sum(rejected.values()),
        rejected_geometry_reasons=dict(sorted(rejected.items())),
        duplicate_geometry_groups=len(duplicate_sizes),
        duplicate_geometry_records=sum(duplicate_sizes),
        duplicate_geometry_excess_records=sum(size - 1 for size in duplicate_sizes),
        graph_edges_created=network.graph.number_of_edges(),
        unrepresented_pipe_geometries=len(network.pipes) - network.graph.number_of_edges(),
        endpoint_pair_counts=dict(sorted(pairs.items())),
        missing_endpoint_reference_slots=missing_slots,
        source_manhole_records=len(manholes),
        graph_eligible_manhole_records=len(network.manholes),
        duplicate_manhole_ids=len(network.duplicate_manhole_ids),
    )


def build_network(pipes, manholes):
    # Duplicate municipal GUIDs are ambiguous and cannot safely be joined.
    counts = Counter(f.get('properties', {}).get('OBJECT_GUID') for f in manholes if f.get('properties', {}).get('OBJECT_GUID'))
    duplicates = {k for k, v in counts.items() if v != 1}
    mh = {f['properties']['OBJECT_GUID']: f for f in manholes
          if f.get('properties', {}).get('OBJECT_GUID') and f['properties']['OBJECT_GUID'] not in duplicates and valid_geometry(f, 'manholes')}
    graph = nx.MultiGraph()
    valid = {}
    unresolved = []
    invalid = 0
    for f in pipes:
        if not valid_geometry(f, 'pipes'):
            invalid += 1
            continue
        p = f.get('properties', {})
        # OBJECTID is unique per source layer; retain all original attributes.
        key = str(p.get('OBJECTID'))
        if key == 'None' or key in valid:
            raise ValueError('Missing or duplicate pipe OBJECTID')
        valid[key] = f
        a, b = p.get('BEGINPUT_ID'), p.get('EINDPUT_ID')
        if a not in mh or b not in mh:
            unresolved.append(key)
            continue
        graph.add_edge(a, b, key=key, pipe_id=key)
    return Network(valid, mh, graph, unresolved, invalid, duplicates)


def endpoint_summary(network):
    """Count endpoint references and unique IDs, distinguishing nulls from unmatched IDs."""
    endpoints = [f['properties'].get(name) for f in network.pipes.values()
                 for name in ('BEGINPUT_ID', 'EINDPUT_ID')]
    ids = {value for value in endpoints if value is not None and value != ''}
    return {'missing_references': sum(value is None or value == '' for value in endpoints),
            'matched_unique_ids': len(ids & network.manholes.keys()),
            'unmatched_unique_ids': len(ids - network.manholes.keys())}


def summary(g):
    comps = list(nx.connected_components(g))
    return {'nodes': g.number_of_nodes(), 'edges': g.number_of_edges(),
            'components': len(comps), 'largest_component_nodes': max(map(len, comps), default=0)}


def structural_analysis(g):
    # NetworkX bridges correctly handles parallel edges in a MultiGraph.
    bridge_pairs = list(nx.bridges(g))
    bridge_ids = {str(k) for u, v in bridge_pairs for k in g[u][v]}
    articulation = set(nx.articulation_points(g))
    return bridge_ids, articulation


def simulate_failure(g, removed):
    requested = set(map(str, removed))
    before = list(nx.connected_components(g))
    after = g.copy()
    present = {str(k) for _, _, k in g.edges(keys=True)}
    unknown = requested - present
    if unknown:
        raise ValueError(f'Unknown or unconnected pipes: {sorted(unknown)}')
    after.remove_edges_from([(u, v, k) for u, v, k in g.edges(keys=True) if str(k) in requested])
    disconnected = set()
    for component in before:
        pieces = sorted(nx.connected_components(after.subgraph(component)), key=lambda s: (-len(s), min(map(str, s))))
        for piece in pieces[1:]:
            disconnected.update(piece)
    return after, disconnected
