"""Interactive map and graph visualization components for FloodCut.

Distinguishes:
- REAL:IMD_GRID: Official IMD 0.25 deg grid cell centre.
- DERIVED:GEOCODED: Approximate waterlogging hotspot points from civic reports.
- SYNTHETIC: Illustrative drainage network nodes and conduits (not surveyed).
"""

from __future__ import annotations

import folium
import matplotlib.pyplot as plt
from branca.element import Element
from folium.plugins import PolyLineTextPath
from matplotlib.lines import Line2D

from floodcut.geo_loader import GeoLayer
from floodcut.models import DrainageNetwork
from floodcut.provenance import SYNTHETIC


def build_mumbai_folium_map(
    net: DrainageNetwork,
    imd_grid: GeoLayer,
    hotspots: GeoLayer,
    show_drains: bool = True,
    show_hotspots: bool = True,
    show_imd_grid: bool = True,
    show_catchments: bool = True,
    show_nodes: bool = True,
    show_junctions: bool = True,
    show_outfalls: bool = True,
    flow_result=None,
) -> folium.Map:
    """Create a Folium map visualizing Mumbai drainage and geospatial layers.

    All features carry explicit provenance tags in popups and labels.
    """
    # Center map on Mumbai drainage area (~19.01 N, 72.84 E)
    m = folium.Map(
        location=[19.015, 72.842],
        zoom_start=12,
        tiles="OpenStreetMap",
        control_scale=True,
    )
    network_provenance = _network_provenance_label(net)
    cut_drain_ids = _min_cut_drain_ids(flow_result)

    # 1. Drainage conduits, preserving the network's declared provenance.
    if show_drains:
        drain_group = folium.FeatureGroup(
            name=f"Drainage Conduits ({network_provenance})", show=True
        )
        for d in net.drains.values():
            j_from = net.junctions.get(d.from_junction)
            j_to = net.junctions.get(d.to_junction)
            if not j_from or not j_to:
                continue

            is_bottleneck = d.id in cut_drain_ids
            color = (
                "#8e24aa"
                if is_bottleneck
                else "#d9534f" if d.capacity_factor < 1.0 else "#0275d8"
            )
            dash = "5, 5" if d.capacity_factor < 1.0 else None
            weight = (
                6
                if is_bottleneck
                else 4 if d.kind in ("open_nallah", "box_drain") else 2.5
            )
            drain_flow = (
                flow_result.drain_flow_m3s.get(d.id)
                if flow_result is not None
                else None
            )
            flow_line = (
                f"<b>Model flow:</b> {drain_flow:.2f} m³/s<br/>"
                if drain_flow is not None
                else ""
            )
            bottleneck_line = (
                "<b style='color:#8e24aa;'>MODEL BOTTLENECK:</b> "
                "minimum-cut drain for the selected screening scenario.<br/>"
                if is_bottleneck
                else ""
            )

            popup_html = f"""
            <div style="font-family: Arial, sans-serif; min-width: 180px;">
                <b style="color: {color};">Drain: {d.id}</b><br/>
                <b>Kind:</b> {d.kind}<br/>
                <b>Path:</b> {d.from_junction} &rarr; {d.to_junction}<br/>
                <b>Design Cap:</b> {d.design_capacity_m3s:.2f} m³/s<br/>
                <b>Effective Cap:</b> {d.effective_capacity_m3s:.2f} m³/s<br/>
                {flow_line}
                <b>Condition:</b> {d.capacity_factor * 100:.0f}% healthy<br/>
                <b>Repair Cost:</b> {d.repair_cost:.1f} units<br/>
                {bottleneck_line}
                <hr style="margin: 4px 0;"/>
                <span style="font-size: 10px; color: #777;">
                    PROVENANCE: <b>{network_provenance}</b>
                </span>
            </div>
            """

            line = folium.PolyLine(
                locations=[[j_from.lat, j_from.lon], [j_to.lat, j_to.lon]],
                color=color,
                weight=weight,
                opacity=0.8,
                dash_array=dash,
                tooltip=(
                    f"Drain {d.id}: {d.effective_capacity_m3s:.1f} m³/s "
                    f"[{network_provenance}]"
                ),
                popup=folium.Popup(popup_html, max_width=250),
            ).add_to(drain_group)
            PolyLineTextPath(
                line,
                "▶",
                repeat=True,
                offset=7,
                attributes={
                    "fill": color,
                    "font-weight": "bold",
                    "font-size": "12",
                },
            ).add_to(drain_group)

        drain_group.add_to(m)

    # Junctions / inlets / outfalls share the network provenance, but remain
    # independently toggleable from the drainage edge layer.
    if show_nodes:
        node_group = folium.FeatureGroup(
            name=f"Network Nodes ({network_provenance})", show=True
        )
        for j in net.junctions.values():
            is_outfall = j.id in net.outfalls
            if is_outfall and not show_outfalls:
                continue
            if not is_outfall and not show_junctions:
                continue
            fill_color = "#5cb85c" if is_outfall else "#337ab7"
            radius = 7 if is_outfall else 5
            icon_name = "tint" if is_outfall else "circle"

            popup_html = f"""
            <div style="font-family: Arial, sans-serif; min-width: 160px;">
                <b>Node: {j.id}</b> ({j.name})<br/>
                <b>Type:</b> {"Outfall (Tidal Sink)" if is_outfall else "Network Inlet / Junction"}<br/>
                <b>Coordinates:</b> {j.lat:.4f}°N, {j.lon:.4f}°E<br/>
                <hr style="margin: 4px 0;"/>
                <span style="font-size: 10px; color: #777;">
                    PROVENANCE: <b>{network_provenance}</b>
                </span>
            </div>
            """

            folium.CircleMarker(
                location=[j.lat, j.lon],
                radius=radius,
                color="#222",
                weight=1.5,
                fill=True,
                fill_color=fill_color,
                fill_opacity=0.9,
                tooltip=f"{'Outfall' if is_outfall else 'Junction'} {j.id}: {j.name}",
                popup=folium.Popup(popup_html, max_width=240),
            ).add_to(node_group)

        node_group.add_to(m)

    if show_catchments:
        catchment_group = folium.FeatureGroup(
            name=f"Catchment Allocation Points ({network_provenance})", show=True
        )
        for catchment in net.catchments.values():
            junction = net.junctions.get(catchment.junction_id)
            if junction is None:
                continue
            folium.CircleMarker(
                location=[junction.lat, junction.lon],
                radius=8,
                color="#6a1b9a",
                weight=2,
                fill=False,
                tooltip=f"Catchment {catchment.id}: {catchment.area_ha:g} ha allocation point",
                popup=folium.Popup(
                    f"<b>{catchment.name}</b><br/>Area record: {catchment.area_ha:g} ha<br/>"
                    f"Runoff coefficient: {catchment.runoff_coefficient:g}<br/>"
                    "Boundary geometry is unavailable; this symbol is the model inlet, not an area polygon.",
                    max_width=280,
                ),
            ).add_to(catchment_group)
        catchment_group.add_to(m)

    # 2. Waterlogging Hotspots (DERIVED:GEOCODED)
    if show_hotspots:
        hotspot_group = folium.FeatureGroup(name="Waterlogging Hotspots (DERIVED:GEOCODED)", show=True)
        for pt in hotspots.points:
            ward = pt.attributes.get("ward", "Unknown")
            notes = pt.attributes.get("notes", "")

            popup_html = f"""
            <div style="font-family: Arial, sans-serif; min-width: 190px;">
                <b style="color: #e65100;">⚠️ Hotspot: {pt.name}</b><br/>
                <b>Ward:</b> {ward}<br/>
                <b>Coordinates:</b> {pt.lat:.4f}°N, {pt.lon:.4f}°E<br/>
                <b>Notes:</b> {notes}<br/>
                <hr style="margin: 4px 0;"/>
                <span style="font-size: 10px; color: #b71c1c;">
                    PROVENANCE: <b>DERIVED:GEOCODED</b><br/>
                    Approx. location from civic reports (&plusmn;500m).<br/>
                    Not a measured flood depth or extent polygon.
                </span>
            </div>
            """

            folium.Marker(
                location=[pt.lat, pt.lon],
                icon=folium.Icon(color="orange", icon="warning-sign", prefix="glyphicon"),
                tooltip=f"Hotspot: {pt.name} (Ward {ward})",
                popup=folium.Popup(popup_html, max_width=260),
            ).add_to(hotspot_group)

        hotspot_group.add_to(m)

    # 3. IMD Grid Point (REAL:IMD_GRID)
    if show_imd_grid:
        grid_group = folium.FeatureGroup(name="IMD Rainfall Grid (REAL:IMD_GRID)", show=True)
        for pt in imd_grid.points:
            res = pt.attributes.get("grid_resolution_deg", "0.25")
            source = pt.attributes.get("data_source", "IMD via OpenCity")

            popup_html = f"""
            <div style="font-family: Arial, sans-serif; min-width: 200px;">
                <b style="color: #2e7d32;">🌧️ {pt.name}</b><br/>
                <b>ID:</b> {pt.id}<br/>
                <b>Grid Resolution:</b> {res}° &times; {res}°<br/>
                <b>Coordinates:</b> {pt.lat:.4f}°N, {pt.lon:.4f}°E<br/>
                <b>Source:</b> {source}<br/>
                <hr style="margin: 4px 0;"/>
                <span style="font-size: 10px; color: #1b5e20;">
                    PROVENANCE: <b>REAL:IMD_GRID</b><br/>
                    Cell centre of IMD 0.25° gridded observational dataset.
                </span>
            </div>
            """

            # Draw representative 0.25x0.25 degree boundary box (~27km x 27km)
            dlat = 0.125
            dlon = 0.125
            folium.Rectangle(
                bounds=[[pt.lat - dlat, pt.lon - dlon], [pt.lat + dlat, pt.lon + dlon]],
                color="#2e7d32",
                weight=1.5,
                fill=True,
                fill_color="#81c784",
                fill_opacity=0.15,
                tooltip="IMD 0.25° Grid Cell Area [REAL:IMD_GRID]",
            ).add_to(grid_group)

            folium.Marker(
                location=[pt.lat, pt.lon],
                icon=folium.Icon(color="green", icon="cloud", prefix="glyphicon"),
                tooltip=f"IMD rainfall grid point: {pt.name} [REAL:IMD_GRID]",
                popup=folium.Popup(popup_html, max_width=280),
            ).add_to(grid_group)

        grid_group.add_to(m)

    # Add interactive layer controls
    folium.LayerControl(position="topright", collapsed=False).add_to(m)

    # Add on-map custom HTML legend with an explicit three-category key.
    legend_html = """
    <div style="
        position: fixed;
        bottom: 20px;
        left: 20px;
        z-index: 9999;
        background-color: white;
        padding: 10px 14px;
        border-radius: 6px;
        box-shadow: 0 0 10px rgba(0,0,0,0.25);
        font-family: Arial, sans-serif;
        font-size: 12px;
        line-height: 1.5;
    ">
        <b style="font-size: 13px;">FloodCut Map Legend</b><br/>
        <b>REAL</b> — IMD rainfall grid-cell centre only<br/>
        <b>DERIVED</b> — approximate geocoded hotspot<br/>
        <b>SYNTHETIC</b> — illustrative network unless source metadata says otherwise<br/>
        <span style="color: #2e7d32;">■</span> IMD rainfall grid point<br/>
        <span style="color: #e65100;">▲</span> Waterlogging hotspot<br/>
        <span style="color: #0275d8;">—</span> Drain / pipe branch; ▶ modeled direction<br/>
        <span style="color: #8e24aa;">━━</span> Model minimum-cut bottleneck<br/>
        <span style="color: #5cb85c;">●</span> Outfall &nbsp;
        <span style="color: #337ab7;">●</span> Junction
    </div>
    """
    m.get_root().html.add_child(Element(legend_html))

    return m


def plot_offline_drainage_graph(
    net: DrainageNetwork,
    flow_result=None,
    *,
    highlight_drain_ids=(),
) -> plt.Figure:
    """Offline graph view with capacities, directed flow, and min-cut emphasis."""
    fig, ax = plt.subplots(figsize=(10, 7), dpi=100)
    highlight_drain_ids = set(highlight_drain_ids)
    _draw_network(ax, net, flow_result, highlight_drain_ids)
    provenance = _network_provenance_label(net)
    scenario = getattr(flow_result, "scenario_id", "no flow scenario")
    ax.set_title(
        f"Drainage Network Topology ({provenance})\n"
        f"Edge labels: drain ID · model flow / effective capacity (m³/s); "
        f"model min-cut bottlenecks from {scenario}",
        fontsize=11,
        fontweight="bold",
    )
    ax.set_xlabel("Longitude (°E)", fontsize=9)
    ax.set_ylabel("Latitude (°N)", fontsize=9)
    ax.grid(True, linestyle="--", alpha=0.5)
    _apply_network_bounds(ax, net)
    ax.legend(
        handles=_network_legend(bool(highlight_drain_ids)),
        loc="best",
        fontsize=8,
    )
    fig.tight_layout()
    return fig


def plot_drainage_network_schematic(
    net: DrainageNetwork,
    imd_grid: GeoLayer,
    hotspots: GeoLayer,
    *,
    flow_result=None,
    show_drains: bool = True,
    show_hotspots: bool = True,
    show_imd_grid: bool = True,
    highlight_drain_ids=(),
) -> plt.Figure:
    """Render the network and existing geospatial layers on shared coordinates.

    The model network retains its own declared provenance. REAL:IMD_GRID is
    shown only as rainfall data, while approximate civic hotspots remain
    DERIVED:GEOCODED.
    """
    fig, ax = plt.subplots(figsize=(12, 8), dpi=110)
    highlight_drain_ids = set(highlight_drain_ids)
    if show_drains:
        _draw_network(ax, net, flow_result, highlight_drain_ids)

    legend_handles = []
    if show_drains:
        legend_handles.extend(_network_legend(bool(highlight_drain_ids)))

    if show_hotspots:
        for pt in hotspots.points:
            ax.scatter(
                pt.lon,
                pt.lat,
                marker="^",
                s=90,
                color="#e65100",
                edgecolor="white",
                linewidth=0.8,
                zorder=7,
            )
            ax.annotate(
                pt.name,
                (pt.lon, pt.lat),
                xytext=(5, 5),
                textcoords="offset points",
                fontsize=7,
                color="#8a2c00",
                zorder=8,
            )
        if hotspots.points:
            legend_handles.append(
                Line2D(
                    [], [], marker="^", linestyle="None", color="#e65100",
                    label="Hotspot (DERIVED:GEOCODED; approximate)",
                )
            )

    if show_imd_grid:
        for pt in imd_grid.points:
            ax.scatter(
                pt.lon,
                pt.lat,
                marker="o",
                s=120,
                color="#2e7d32",
                edgecolor="white",
                linewidth=1,
                zorder=9,
            )
            ax.annotate(
                f"{pt.name}\nREAL:IMD_GRID rainfall cell centre",
                (pt.lon, pt.lat),
                xytext=(7, -20),
                textcoords="offset points",
                fontsize=7,
                color="#1b5e20",
                zorder=10,
            )
        if imd_grid.points:
            legend_handles.append(
                Line2D(
                    [], [], marker="o", linestyle="None", color="#2e7d32",
                    label="Rainfall grid point (REAL:IMD_GRID; not drainage)",
                )
            )

    provenance = _network_provenance_label(net)
    scenario = getattr(flow_result, "scenario_id", "no flow scenario")
    ax.set_title(
        "Mumbai Drainage Network Schematic\n"
        f"Network: {provenance} · model flow/min-cut scenario: {scenario}",
        fontsize=12,
        fontweight="bold",
    )
    ax.set_xlabel("Longitude (°E)", fontsize=9)
    ax.set_ylabel("Latitude (°N)", fontsize=9)
    ax.grid(True, linestyle="--", alpha=0.35)
    ax.set_aspect("equal", adjustable="datalim")
    _apply_network_bounds(ax, net, imd_grid if show_imd_grid else None,
                          hotspots if show_hotspots else None)
    if legend_handles:
        ax.legend(handles=legend_handles, loc="best", fontsize=7, framealpha=0.95)
    fig.text(
        0.5,
        0.015,
        "Engineering screening schematic, not a surveyed BMC/MCGM drainage map. "
        "Model bottlenecks are scenario-derived.",
        ha="center",
        fontsize=8,
        color="#555",
    )
    fig.tight_layout(rect=(0, 0.035, 1, 1))
    return fig


def _network_provenance_label(net: DrainageNetwork) -> str:
    declared = getattr(net.metadata, "provenance", None)
    if declared:
        return declared
    if net.metadata.is_simulated:
        return SYNTHETIC
    return "PROVENANCE NOT DECLARED"


def _min_cut_drain_ids(flow_result) -> set[str]:
    if flow_result is None:
        return set()
    return {
        edge.ref for edge in flow_result.min_cut_edges
        if edge.kind == "drain"
    }


def _network_legend(include_repaired: bool = False) -> list:
    handles = [
        Line2D([], [], color="#0275d8", linewidth=2, label="Drain / pipe branch"),
        Line2D([], [], color="#d9534f", linewidth=2, linestyle="--",
               label="Degraded drain"),
        Line2D([], [], color="#8e24aa", linewidth=3,
               label="Model min-cut bottleneck"),
        Line2D([], [], marker="o", linestyle="None", color="#337ab7",
               label="Junction / inlet"),
        Line2D([], [], marker="o", linestyle="None", color="#5cb85c",
               label="Outfall"),
    ]
    if include_repaired:
        handles.append(
            Line2D([], [], color="#00897b", linewidth=3,
                   label="Restored by selected repair plan")
        )
    return handles


def _draw_network(
    ax, net: DrainageNetwork, flow_result=None, highlight_drain_ids=()
) -> None:
    """Draw each conduit separately so parallel drains remain visible."""
    positions = {
        jid: (junction.lon, junction.lat)
        for jid, junction in net.junctions.items()
    }
    cut_drain_ids = _min_cut_drain_ids(flow_result)
    highlight_drain_ids = set(highlight_drain_ids)
    edge_counts: dict[tuple[str, str], int] = {}
    pair_counts: dict[tuple[str, str], int] = {}
    for candidate in net.drains.values():
        pair = (candidate.from_junction, candidate.to_junction)
        pair_counts[pair] = pair_counts.get(pair, 0) + 1

    for drain in net.drains.values():
        pair = (drain.from_junction, drain.to_junction)
        offset_index = edge_counts.get(pair, 0)
        edge_counts[pair] = offset_index + 1
        start = positions.get(drain.from_junction)
        end = positions.get(drain.to_junction)
        if start is None or end is None:
            continue

        is_bottleneck = drain.id in cut_drain_ids
        is_repaired = drain.id in highlight_drain_ids
        color = (
            "#8e24aa"
            if is_bottleneck
            else "#00897b" if is_repaired
            else "#d9534f" if drain.capacity_factor < 1.0 else "#0275d8"
        )
        parallel_count = pair_counts[pair]
        curve = (offset_index - (parallel_count - 1) / 2) * 0.18
        ax.annotate(
            "",
            xy=end,
            xytext=start,
            arrowprops={
                "arrowstyle": "-|>",
                "color": color,
                "linewidth": 3 if is_bottleneck else 1.8,
                "linestyle": "--" if drain.capacity_factor < 1.0 else "-",
                "connectionstyle": f"arc3,rad={curve}",
                "shrinkA": 9,
                "shrinkB": 9,
            },
            zorder=3,
        )

        flow = (
            flow_result.drain_flow_m3s.get(drain.id, 0.0)
            if flow_result is not None
            else None
        )
        capacity = drain.effective_capacity_m3s
        label = (
            f"{drain.id} {flow:.1f}/{capacity:.1f}"
            if flow is not None
            else f"{drain.id} {capacity:.1f} m³/s"
        )
        if is_repaired:
            label += " restored"
        midpoint = ((start[0] + end[0]) / 2, (start[1] + end[1]) / 2)
        ax.annotate(
            label,
            midpoint,
            xytext=(0, 5 + offset_index * 5),
            textcoords="offset points",
            fontsize=6.5,
            color=color,
            ha="center",
            va="center",
            bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.72,
                  "pad": 0.5},
            zorder=5,
        )

    for jid, junction in net.junctions.items():
        is_outfall = jid in net.outfalls
        color = "#5cb85c" if is_outfall else "#337ab7"
        ax.scatter(
            junction.lon,
            junction.lat,
            s=74 if is_outfall else 48,
            color=color,
            edgecolor="white",
            linewidth=0.8,
            zorder=6,
        )
        ax.annotate(
            jid,
            (junction.lon, junction.lat),
            xytext=(0, 7),
            textcoords="offset points",
            fontsize=6.5,
            ha="center",
            color="#263238",
            zorder=7,
        )


def _apply_network_bounds(ax, net, imd_grid=None, hotspots=None) -> None:
    coordinates = [
        (junction.lon, junction.lat) for junction in net.junctions.values()
    ]
    if imd_grid is not None:
        coordinates.extend((point.lon, point.lat) for point in imd_grid.points)
    if hotspots is not None:
        coordinates.extend((point.lon, point.lat) for point in hotspots.points)
    if not coordinates:
        return
    longitudes, latitudes = zip(*coordinates)
    lon_span = max(longitudes) - min(longitudes)
    lat_span = max(latitudes) - min(latitudes)
    lon_pad = max(lon_span * 0.08, 0.003)
    lat_pad = max(lat_span * 0.08, 0.003)
    ax.set_xlim(min(longitudes) - lon_pad, max(longitudes) + lon_pad)
    ax.set_ylim(min(latitudes) - lat_pad, max(latitudes) + lat_pad)
