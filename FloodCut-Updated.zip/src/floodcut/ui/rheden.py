"""Rheden user interface: municipal records, structural analysis and KNMI."""
from datetime import datetime, timedelta, timezone
import html
import pandas as pd
import streamlit as st
import folium
from streamlit_folium import st_folium
from floodcut import rheden, knmi


@st.cache_data(ttl=86400, show_spinner='Retrieving municipal pipe and manhole records…')
def load_data():
    return rheden.fetch_layer('pipes'), rheden.fetch_layer('manholes')


@st.cache_resource(ttl=86400)
def load_network():
    return rheden.build_network(*load_data())


@st.cache_data(ttl=3600)
def load_rain(start, end):
    return knmi.fetch_hourly(start, end)


def attrs(feature):
    return pd.DataFrame([{'Attribute': str(k), 'Value': str(v) if v is not None else '—'}
                         for k, v in feature['properties'].items()])


def coords(feature):
    geo = feature['geometry']
    if geo['type'] == 'LineString':
        return [[[lat, lon] for lon, lat, *_ in geo['coordinates']]]
    return [[[lat, lon] for lon, lat, *_ in part] for part in geo['coordinates']]


def render():
    st.header('🇳🇱 Rheden — municipal infrastructure')
    st.info('Real recorded pipe geometries and manhole locations. The derived graph is UNDIRECTED and may be incomplete. Structural results are not hydraulic flood predictions.')
    st.caption('Source: Municipality of Rheden ArcGIS open data (2021 item metadata); network is fetched on demand. Endpoint order does not establish flow direction.')
    try:
        net = load_network()
        import_audit = rheden.reconcile_import(*load_data(), net)
    except Exception as exc:
        st.error(f'Municipal records could not be loaded: {exc}. Check connectivity and retry.')
        if st.button('Retry municipal data'):
            load_data.clear(); load_network.clear(); st.rerun()
        return
    graph = net.graph
    if not net.pipes:
        st.warning('The service returned no valid pipe geometries.')
        return
    bridges, points = rheden.structural_analysis(graph)
    st.markdown('**Hydraulic maximum flow, hydraulic minimum cut and financial repair optimization are unavailable:** municipal field units, datum and engineering meaning, capacities, directions and costs have not been verified.')
    with st.expander('Dataset and connectivity', expanded=True):
        a,b,c,d = st.columns(4)
        a.metric('Valid pipe geometries', len(net.pipes))
        b.metric('Graph pipe edges', graph.number_of_edges())
        c.metric('Graph manholes', graph.number_of_nodes())
        d.metric('Components', rheden.summary(graph)['components'])
        st.write(f'{len(net.unresolved):,} valid pipe records have an unresolved endpoint and are excluded from the graph; {net.invalid_pipes:,} pipe geometries are invalid. {len(net.duplicate_manhole_ids):,} manhole IDs are ambiguous.')
        endpoints = rheden.endpoint_summary(net)
        st.write(f"Endpoint IDs: {endpoints['matched_unique_ids']:,} unique IDs match manholes; {endpoints['unmatched_unique_ids']:,} unique IDs do not match; {endpoints['missing_references']:,} endpoint references are blank.")
        st.write(f'{len(bridges):,} structural bridge pipes; {len(points):,} articulation manholes. Matching endpoints does not imply a single connected network.')
        st.markdown('**Import reconciliation**')
        st.dataframe(pd.DataFrame([
            {'Item': 'Original pipe records', 'Records': import_audit.original_pipe_records,
             'Treatment': 'Complete OBJECTID snapshot'},
            {'Item': 'Valid pipe geometries', 'Records': import_audit.valid_pipe_geometries,
             'Treatment': 'Preserved for map and inspection'},
            {'Item': 'Rejected geometries', 'Records': import_audit.rejected_pipe_geometries,
             'Treatment': str(import_audit.rejected_geometry_reasons) or 'None'},
            {'Item': 'Exact duplicate-geometry records', 'Records': import_audit.duplicate_geometry_records,
             'Treatment': f'Preserved in {import_audit.duplicate_geometry_groups} groups; not merged'},
            {'Item': 'Graph edges created', 'Records': import_audit.graph_edges_created,
             'Treatment': 'Both endpoint IDs exactly matched'},
            {'Item': 'Unrepresented valid geometries', 'Records': import_audit.unrepresented_pipe_geometries,
             'Treatment': 'At least one endpoint could not be joined'},
        ]), hide_index=True, use_container_width=True)
        st.caption(
            f'{import_audit.missing_endpoint_reference_slots:,} endpoint reference slots are blank. '
            'No spatial snapping, geometry splitting, or geometry deduplication is performed.'
        )
    tabs = st.tabs(['Explore & simulate', 'Structural ranking', 'KNMI rainfall'])
    with tabs[0]:
        pipe_choices = sorted(net.pipes, key=lambda x: int(x))
        manhole_choices = sorted(net.manholes)
        kind = st.radio('Inspect infrastructure', ['Pipe', 'Manhole'], horizontal=True, key='rheden_kind')
        selected_pipe = None
        selected_node = None
        if kind == 'Pipe':
            selected_pipe = st.selectbox('Pipe OBJECTID', pipe_choices, key='rheden_pipe')
            feature = net.pipes[selected_pipe]
            p = feature['properties']
            st.write('Municipal pipe ID:', p.get('ID'), '| endpoints:', p.get('BEGINPUT_ID'), '→', p.get('EINDPUT_ID'), '(identifiers only)')
            st.write('Graph status:', 'unresolved endpoint' if selected_pipe in net.unresolved else 'joined', '| structural bridge:', selected_pipe in bridges)
            neighbor_pipes = {str(k) for endpoint in (p.get('BEGINPUT_ID'), p.get('EINDPUT_ID')) if endpoint in graph for _, _, k in graph.edges(endpoint, keys=True)} - {selected_pipe}
            st.write('Connected pipe OBJECTIDs:', ', '.join(sorted(neighbor_pipes)) or 'None in derived graph')
        else:
            selected_node = st.selectbox('Manhole OBJECT_GUID', manhole_choices, key='rheden_node')
            feature = net.manholes[selected_node]
            adjacent = list(graph.edges(selected_node, keys=True)) if selected_node in graph else []
            st.write('Connected pipe OBJECTIDs:', ', '.join(str(k) for _, _, k in adjacent) or 'None in derived graph')
        with st.expander('Original municipal attributes'):
            st.dataframe(attrs(feature), hide_index=True, use_container_width=True)
        eligible = sorted((str(k) for _,_,k in graph.edges(keys=True)), key=lambda x: int(x))
        def reset_scenario():
            st.session_state.rheden_failures = []
        st.button('Reset scenario', key='rheden_reset', on_click=reset_scenario)
        selected = st.multiselect('Pipes to remove (OBJECTID)', eligible, key='rheden_failures')
        after, disconnected = rheden.simulate_failure(graph, selected)
        before_stats, after_stats = rheden.summary(graph), rheden.summary(after)
        st.dataframe(pd.DataFrame({'Before':before_stats, 'After':after_stats}), use_container_width=True)
        st.caption(f'{len(disconnected):,} manholes are in sections separated from the largest remainder of their original component. Ties are resolved deterministically; no outlet or service impact is inferred.')
        max_display = min(10000, len(pipe_choices))
        limit = st.slider('Maximum pipe geometries drawn', 500, max_display, min(3000, max_display), step=500) if max_display > 500 else max_display
        drawn = pipe_choices[:limit]
        st.caption(f'Map displays {len(drawn):,} of {len(pipe_choices):,} valid pipe geometries, plus selected and affected pipes. Statistics use all valid records. Zoom and use the selector to inspect any pipe.')
        m = folium.Map(location=[52.02, 6.03], zoom_start=12, tiles='OpenStreetMap', prefer_canvas=True)
        affected = {str(k) for u,v,k in after.edges(keys=True) if u in disconnected and v in disconnected}
        special = set(selected) | affected
        if selected_pipe:
            special.add(selected_pipe)
            special.update(neighbor_pipes)
        if selected_node and selected_node in graph: special.update(str(k) for _,_,k in graph.edges(selected_node, keys=True))
        visible = set(drawn) | special
        for pid in visible:
            if pid not in net.pipes: continue
            f = net.pipes[pid]
            color = '#f04438' if pid in selected else '#ed9d17' if pid in affected else '#8b2de2' if (selected_pipe and (pid == selected_pipe or pid in neighbor_pipes)) or (selected_node and pid in special) else '#087f8c'
            for line in coords(f):
                folium.PolyLine(line, color=color, weight=4 if pid in special else 2, opacity=.9 if pid in special else .65,
                                tooltip='Pipe OBJECTID ' + html.escape(pid)).add_to(m)
        # Isolated nodes have no remaining pipe geometry to color.
        for node in disconnected:
            if after.degree(node) == 0 and node in net.manholes:
                xy = net.manholes[node]['geometry']['coordinates']
                folium.CircleMarker([xy[1], xy[0]], radius=4, color='#ed9d17', fill=True,
                                    tooltip='Separated manhole ' + html.escape(str(node))).add_to(m)
        if selected_node:
            xy = feature['geometry']['coordinates']
            folium.CircleMarker([xy[1], xy[0]], radius=7, color='#8b2de2', fill=True, tooltip=html.escape(selected_node)).add_to(m)
        elif selected_pipe:
            for endpoint in (feature['properties'].get('BEGINPUT_ID'), feature['properties'].get('EINDPUT_ID')):
                if endpoint in net.manholes:
                    xy = net.manholes[endpoint]['geometry']['coordinates']
                    folium.CircleMarker([xy[1], xy[0]], radius=5, color='#8b2de2', fill=True, tooltip=html.escape(str(endpoint))).add_to(m)
        st.caption('Teal: displayed pipes · purple: selection and connected pipes · red: removed · amber: separated section')
        st_folium(m, height=550, width=None, key='rheden_map', returned_objects=[])
    with tabs[1]:
        st.write('Structural bridges are ranked by the size of the smaller side when removed; this measures topology, not hydraulic criticality. Articulation points are ranked by degree.')
        ranked = rank_bridges(graph, bridges)
        st.dataframe(pd.DataFrame(ranked, columns=['Pipe OBJECTID', 'Smaller side (manholes)']), hide_index=True, use_container_width=True)
        st.dataframe(pd.DataFrame(sorted(((n, graph.degree(n)) for n in points), key=lambda x: (-x[1], x[0])), columns=['Articulation manhole GUID', 'Degree']), hide_index=True, use_container_width=True)
    with tabs[2]:
        render_rain()


def rank_bridges(_graph, bridge_ids):
    # One traversal computes subtree sizes and bridge impact within each component.
    import networkx as nx
    result = []
    simple = nx.Graph(_graph)
    for nodes in nx.connected_components(simple):
        component = simple.subgraph(nodes)
        if len(nodes) < 2: continue
        root = next(iter(nodes))
        tree = nx.dfs_tree(component, root)
        sizes = {v: 1 for v in nodes}
        for n in reversed(list(nx.topological_sort(tree))):
            for child in tree.successors(n): sizes[n] += sizes[child]
            for parent in tree.predecessors(n):
                for k in _graph[parent][n]:
                    if str(k) in bridge_ids:
                        result.append((str(k), min(sizes[n], len(nodes)-sizes[n])))
    return sorted(result, key=lambda x: (-x[1], x[0]))


def render_rain():
    st.write('KNMI hourly observations, station 275 Deelen Airport, outside Rheden. These observations are not local measurements at each pipe. Times are UTC and denote the end of each hour.')
    today = datetime.now(timezone.utc).date()
    days = st.slider('Past days requested', 1, 31, 7, key='rheden_days')
    if st.button('Load KNMI hourly observations', key='rheden_rain_load'):
        st.session_state.rheden_rain_requested = True
    if not st.session_state.get('rheden_rain_requested'): return
    end = datetime.now(timezone.utc).replace(minute=0, second=0, microsecond=0)
    start = end - timedelta(days=days) + timedelta(hours=1)
    try:
        rows = load_rain(start, end)
    except Exception as exc:
        st.error(f'KNMI observations could not be loaded: {exc}')
        return
    frame = pd.DataFrame(rows).set_index('time_utc')
    observed = frame[~frame['missing']]
    if observed.empty or end - observed.index.max().to_pydatetime() > timedelta(hours=48):
        st.warning('Observations are stale or unavailable: the latest recorded hour is more than 48 hours old.')
    st.line_chart(frame[['rain_mm']], y_label='Hourly rainfall (mm)')
    st.caption(f"{int(frame['missing'].sum())} missing hours; {int(frame['trace'].sum())} trace hours (<0.05 mm). Traces are shown separately, not converted to zero.")
    st.dataframe(frame, use_container_width=True)
    st.link_button('KNMI hourly data and documentation', 'https://www.daggegevens.knmi.nl/klimatologie/uurgegevens')
