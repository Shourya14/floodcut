"""KNMI Deelen hourly precipitation (RH), timestamps denote hour ending in UTC."""
from datetime import datetime, timedelta, timezone
from urllib.parse import urlencode
from urllib.request import urlopen

URL = 'https://www.daggegevens.knmi.nl/klimatologie/uurgegevens'


def parse_hourly(text, start, end):
    """Fill absent hours, preserving blank observations and RH=-1 traces."""
    values = {}
    for line in text.splitlines():
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        fields = [x.strip() for x in line.split(',')]
        if len(fields) < 4 or fields[0] != '275':
            continue
        try:
            hh = int(fields[2])
            if not 1 <= hh <= 24:
                continue
            dt = datetime.strptime(fields[1], '%Y%m%d').replace(tzinfo=timezone.utc) + timedelta(hours=hh)
            raw = None if fields[3] == '' else int(fields[3])
        except ValueError:
            continue
        if raw is not None and raw < -1:
            raw = None
        values[dt] = raw
    rows = []
    dt = start
    while dt <= end:
        raw = values.get(dt)
        rows.append({'time_utc': dt, 'rain_mm': None if raw is None or raw == -1 else raw / 10,
                     'trace': raw == -1, 'missing': raw is None})
        dt += timedelta(hours=1)
    return rows


def fetch_hourly(start, end):
    # KNMI accepts day-based queries; include the previous date for hour 24.
    q = urlencode({'stns': '275', 'vars': 'RH', 'start': (start - timedelta(days=1)).strftime('%Y%m%d'),
                   'end': end.strftime('%Y%m%d')})
    with urlopen(URL + '?' + q, timeout=45) as response:
        text = response.read().decode('utf-8')
    if '# STN' not in text:
        raise RuntimeError('KNMI did not return an hourly data table')
    return parse_hourly(text, start, end)
