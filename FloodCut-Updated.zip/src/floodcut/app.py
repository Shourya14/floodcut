"""FloodCut: Mumbai Flood Risk & Drainage Optimization — Phase 6 Dashboard.

Interactive frontend built with Streamlit and Folium for Discrete Mathematics
modeling, flow capacity screening, failure simulation, and repair optimization.
"""

from __future__ import annotations

import pandas as pd
import streamlit as st

try:
    from streamlit_folium import st_folium
    HAS_STREAMLIT_FOLIUM = True
except ImportError:
    HAS_STREAMLIT_FOLIUM = False

from floodcut.failure import apply_failure_percentages, enumerate_failures
from floodcut.graph import build_flow_network
from floodcut.maxflow import analyze
from floodcut.models import RainfallScenario
from floodcut.provenance import SYNTHETIC
from floodcut.repair import (
    _apply_repairs,
    _candidate_drains,
    apply_condition_percentages,
    compare_strategies,
)
from floodcut.ui.charts import (
    plot_flow_comparison,
    plot_monthly_distribution,
    plot_rainfall_trends,
    plot_strategy_comparison,
)
from floodcut.ui.map_view import (
    build_mumbai_folium_map,
    plot_drainage_network_schematic,
    plot_offline_drainage_graph,
)
from floodcut.ui.state import (
    get_drainage_network,
    get_hotspot_layer,
    get_imd_grid_layer,
    get_rainfall_dataset,
    get_scenarios,
)


def main() -> None:
    st.set_page_config(
        page_title="FloodCut — Drainage Network Analysis",
        page_icon="🌊",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    def clear_region_results():
        for key in list(st.session_state):
            if key.startswith("rheden_"):
                del st.session_state[key]

    region = st.sidebar.radio("Region", ["Mumbai 🇮🇳", "Rheden 🇳🇱"], key="region_selector", on_change=clear_region_results)
    if region == "Rheden 🇳🇱":
        from floodcut.ui.rheden import render
        render()
        return
    st.sidebar.caption("Mumbai: SYNTHETIC drainage network + REAL IMD historical rainfall")

    # Load shared datasets
    net = get_drainage_network()
    scenarios = get_scenarios()
    rainfall_ds, is_real_rainfall = get_rainfall_dataset()
    imd_grid = get_imd_grid_layer()
    hotspots = get_hotspot_layer()

    # Sidebar Navigation
    st.sidebar.title("🌊 FloodCut")
    st.sidebar.caption("Discrete Mathematics & Drainage Optimization")
    st.sidebar.markdown("---")

    nav = st.sidebar.radio(
        "Navigation",
        [
            "Interactive Map",
            "Rainfall Explorer",
            "Failure Simulation",
            "Repair Optimization",
        ],
        index=0,
    )

    st.sidebar.markdown("---")
    st.sidebar.markdown(
        """
        **Data Provenance Key**
        - 🟢 `REAL:IMD_GRID` (Observed)
        - 🟠 `DERIVED:GEOCODED` (Approximate)
        - 🔵 `SYNTHETIC` (Model Testbed)
        """
    )
    st.sidebar.info(
        "⚠️ **Disclaimer:** FloodCut is an academic capacity-screening model, "
        "not an operational flood forecast system."
    )

    # Route navigation
    if nav == "Interactive Map":
        render_map(net, imd_grid, hotspots)
    elif nav == "Rainfall Explorer":
        render_rainfall_explorer(
            rainfall_ds,
            is_real_rainfall,
            net,
            scenarios,
        )
    elif nav == "Failure Simulation":
        render_failure_simulation(net, scenarios, rainfall_ds)
    elif nav == "Repair Optimization":
        render_repair_optimization(net, scenarios)


# ---------------------------------------------------------------------------
# Section A: Interactive Map
# ---------------------------------------------------------------------------

def render_map(net, imd_grid, hotspots) -> None:
    network_provenance = (
        getattr(net.metadata, "provenance", None)
        or ("SYNTHETIC" if net.metadata.is_simulated else "PROVENANCE NOT DECLARED")
    )
    st.header("🗺️ Interactive Mumbai Geospatial & Network Map")
    st.markdown(
        "Explore the IMD rainfall-grid reference point alongside derived hotspot points and "
        f"the drainage network (`{network_provenance}`). "
        "Popups provide detailed attributes and explicit provenance tags."
    )

    layer_options = [
        "Drainage network",
        "Catchment allocation points",
        "Network nodes",
        "Waterlogging locations",
        "IMD rainfall",
        "Junctions",
        "Outfalls",
    ]
    selected_layers = st.multiselect(
        "Map layers",
        options=layer_options,
        default=layer_options,
        help="One unified control; each available layer can be toggled independently.",
    )
    show_drains = "Drainage network" in selected_layers
    show_hotspots = "Waterlogging locations" in selected_layers
    show_imd = "IMD rainfall" in selected_layers
    show_catchments = "Catchment allocation points" in selected_layers
    show_nodes = "Network nodes" in selected_layers
    show_junctions = "Junctions" in selected_layers
    show_outfalls = "Outfalls" in selected_layers
    c1, c2 = st.columns([2, 1])
    with c1:
        st.caption(
            "Catchments have area and inlet records but no boundary geometry; the map shows "
            "their allocation points and does not invent polygons or quadrats."
        )
    with c2:
        map_mode = st.radio(
            "Render Engine",
            [
                "Interactive Folium",
                "Offline Graph",
                "Drainage Network Schematic",
            ],
            horizontal=True,
        )

    # Use the existing design scenario to calculate model flows and a
    # scenario-specific minimum cut for both map renderers.
    available_scenarios = get_scenarios()
    design_scenario = available_scenarios.get("design", next(iter(available_scenarios.values())))
    flow_network = build_flow_network(net, design_scenario)
    flow_result = analyze(net, flow_network, cross_check=False)

    if map_mode == "Interactive Folium":
        if HAS_STREAMLIT_FOLIUM:
            m = build_mumbai_folium_map(
                net,
                imd_grid,
                hotspots,
                show_drains=show_drains,
                show_hotspots=show_hotspots,
                show_imd_grid=show_imd,
                show_catchments=show_catchments,
                show_nodes=show_nodes,
                show_junctions=show_junctions,
                show_outfalls=show_outfalls,
                flow_result=flow_result,
            )
            st_folium(m, width="100%", height=550)
        else:
            st.warning("`streamlit-folium` is not available. Falling back to offline graph visualization.")
            fig = plot_offline_drainage_graph(net, flow_result=flow_result)
            st.pyplot(fig)
    elif map_mode == "Drainage Network Schematic":
        st.info(
            "Geographic schematic using the existing network coordinates. "
            f"The network provenance is {network_provenance}; "
            "REAL:IMD_GRID is rainfall data only, "
            "and hotspot locations are DERIVED:GEOCODED."
        )
        fig = plot_drainage_network_schematic(
            net,
            imd_grid,
            hotspots,
            flow_result=flow_result,
            show_drains=show_drains,
            show_hotspots=show_hotspots,
            show_imd_grid=show_imd,
        )
        st.pyplot(fig)
    else:
        st.info("Offline topological view with design-scenario flow and min-cut bottlenecks.")
        fig = plot_offline_drainage_graph(net, flow_result=flow_result)
        st.pyplot(fig)

    with st.expander("Inspect Geospatial Layer Tables"):
        t1, t2 = st.tabs([
            "Waterlogging Hotspots (DERIVED:GEOCODED)",
            "IMD Rainfall Grid Point (REAL:IMD_GRID)",
        ])
        with t1:
            hotspot_data = [
                {
                    "ID": pt.id,
                    "Name": pt.name,
                    "Ward": pt.attributes.get("ward", ""),
                    "Latitude": f"{pt.lat:.4f}°N",
                    "Longitude": f"{pt.lon:.4f}°E",
                    "Notes": pt.attributes.get("notes", ""),
                    "Provenance": pt.provenance,
                }
                for pt in hotspots.points
            ]
            st.dataframe(pd.DataFrame(hotspot_data), use_container_width=True)
        with t2:
            grid_data = [
                {
                    "Grid Point ID": pt.id,
                    "Name": pt.name,
                    "Grid Resolution": f"{pt.attributes.get('grid_resolution_deg', '0.25')}°",
                    "Latitude": f"{pt.lat:.4f}°N",
                    "Longitude": f"{pt.lon:.4f}°E",
                    "Source": pt.attributes.get("data_source", ""),
                    "Provenance": pt.provenance,
                }
                for pt in imd_grid.points
            ]
            st.dataframe(pd.DataFrame(grid_data), use_container_width=True)


# ---------------------------------------------------------------------------
# Section B: Rainfall Explorer
# ---------------------------------------------------------------------------

def render_rainfall_explorer(ds, is_real: bool, net, scenarios) -> None:
    st.header("🌧️ Rainfall Explorer (IMD Historical Observations)")
    st.markdown(
        f"**Dataset:** `{ds.dataset_record.name}` | **Provenance:** `{ds.dataset_record.provenance}` | "
        f"**Coverage:** {ds.dataset_record.observation_period} ({ds.dataset_record.geographic_coverage})"
    )

    if is_real:
        st.success("✅ Displaying verified historical observations from the India Meteorological Department.")
    else:
        st.info("ℹ️ Using offline synthetic fixture.")

    years = ds.years()
    if not years:
        st.error("No rainfall records found.")
        return

    col_filter1, col_filter2 = st.columns([2, 1])
    with col_filter1:
        min_yr, max_yr = int(min(years)), int(max(years))
        selected_range = st.slider("Select Year Span", min_value=min_yr, max_value=max_yr, value=(min_yr, max_yr))
    with col_filter2:
        selected_year = st.selectbox("Inspect Specific Year", options=sorted(years, reverse=True), index=0)

    # Trend Chart
    st.pyplot(plot_rainfall_trends(ds, selected_range))

    # Monthly Breakdown
    st.pyplot(plot_monthly_distribution(ds, selected_year))

    # Keep spatial network context alongside the rainfall XY charts without
    # reclassifying the rainfall record as drainage infrastructure.
    context_scenario = scenarios.get("design", next(iter(scenarios.values())))
    context_result = analyze(
        net,
        build_flow_network(net, context_scenario),
        cross_check=False,
    )
    render_drainage_graph_context(
        net,
        context_result,
        "Drainage Network Context for Rainfall Analysis",
    )

    # Tabular View
    with st.expander(f"View Tabular Observations ({selected_range[0]}–{selected_range[1]})"):
        rows = []
        for r in ds.records:
            if selected_range[0] <= r.year <= selected_range[1]:
                row = {"Year": r.year}
                row.update(r.monthly_mm)
                row["Annual Total (mm)"] = round(r.annual_total_mm() or 0.0, 1)
                row["Monsoon Total (mm)"] = round(r.monsoon_total_mm() or 0.0, 1)
                row["Provenance"] = r.provenance
                rows.append(row)
        df_rain = pd.DataFrame(rows)
        st.dataframe(df_rain, use_container_width=True)


# ---------------------------------------------------------------------------
# Section C: Failure Simulation
# ---------------------------------------------------------------------------

def render_failure_simulation(net, scenarios, rainfall_ds) -> None:
    st.header("⚠️ Drain Failure Simulation (Combinatorial Analysis)")
    st.markdown(
        "Evaluate network resilience by blocking one or more drains. "
        "The model recomputes maximum flow, min cut, and unmet demand shortfall."
    )

    # Scenario selection
    sc_options = list(scenarios.keys())
    c_sc1, c_sc2 = st.columns(2)
    with c_sc1:
        sc_index = sc_options.index("design") if "design" in sc_options else 0
        sc_choice = st.selectbox("Rainfall & Tide Scenario", sc_options, index=sc_index)
        base_scenario = scenarios[sc_choice]
    with c_sc2:
        intensity = st.number_input(
            "Simulated Rainfall Intensity (mm/h)",
            min_value=0.0,
            value=float(base_scenario.intensity_mm_h),
            step=1.0,
            help="User-configured model input, not a historical observation or forecast.",
        )
        base_scenario = RainfallScenario(
            id=f"user_{base_scenario.id}",
            name=f"User-configured {base_scenario.name}",
            intensity_mm_h=float(intensity),
            tide_factor=base_scenario.tide_factor,
            description="User-configured simulation derived from the selected scenario.",
        )
        st.markdown(
            f"**Scenario Profile:** `{base_scenario.name}`\n\n"
            f"- Rainfall Intensity: **{base_scenario.intensity_mm_h:.1f} mm/h**\n"
            f"- Outfall Tide Factor: **{base_scenario.tide_factor:.2f}**"
        )

    # Base analysis
    base_fn = build_flow_network(net, base_scenario)
    base_res = analyze(net, base_fn, cross_check=False)
    graph_net = net
    graph_result = base_res
    graph_heading = "Drainage Network Graph — Baseline Scenario"

    eligible_drains = sorted([d.id for d in net.drains.values() if d.capacity_factor > 0])

    st.markdown("---")
    st.subheader("Simulate Drain Blockages")
    def reset_failures():
        st.session_state["mumbai_failure_selection"] = []
        for did in eligible_drains:
            st.session_state.pop(f"failure_pct_{did}", None)

    st.button("Reset all simulated failures", on_click=reset_failures)
    selected_failures = st.multiselect(
        "Select drains to degrade or block:",
        options=eligible_drains,
        default=[],
        key="mumbai_failure_selection",
        help="Each selected drain gets an independent 0–100% simulated failure control.",
    )

    failure_percentages = {}
    for did in selected_failures:
        failure_percentages[did] = st.slider(
            f"{did} failure percentage",
            min_value=0,
            max_value=100,
            value=100,
            key=f"failure_pct_{did}",
        )

    if selected_failures:
        failed_net = apply_failure_percentages(net, failure_percentages)
        fn_fail = build_flow_network(failed_net, base_scenario)
        fail_res = analyze(failed_net, fn_fail, cross_check=False)
        graph_net = failed_net
        graph_result = fail_res
        graph_heading = "Drainage Network Graph — Selected Failure Scenario"
        added_overflow = fail_res.total_overflow_m3s - base_res.total_overflow_m3s

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Total Rainfall Demand", f"{base_res.total_demand_m3s:.3f} m³/s")
        m2.metric("Deliverable Flow", f"{fail_res.max_flow_m3s:.3f} m³/s", delta=f"{fail_res.max_flow_m3s - base_res.max_flow_m3s:.3f} m³/s")
        m3.metric("Simulated Overflow", f"{fail_res.total_overflow_m3s:.3f} m³/s", delta=f"{added_overflow:+.3f} m³/s", delta_color="inverse")
        m4.metric("Drains Modified", len(selected_failures))

        capacity_rows = []
        for did in selected_failures:
            original = net.drains[did].effective_capacity_m3s
            remaining = failed_net.drains[did].effective_capacity_m3s
            capacity_rows.append({
                "Drain ID": did,
                "Failure (%)": failure_percentages[did],
                "Original Capacity (m³/s)": round(original, 4),
                "Remaining Capacity (m³/s)": round(remaining, 4),
            })
        st.dataframe(pd.DataFrame(capacity_rows), use_container_width=True, hide_index=True)

        st.pyplot(plot_flow_comparison(base_res, fail_res, modified_label=f"Failure of {selected_failures}"))

        with st.expander("Catchment Demand & Shortfall Breakdown"):
            st.caption(
                "Catchment-level shortfall is the allocation from this computed maximum-flow solution. "
                "Where catchments share downstream bottlenecks, the exact shortfall location is not unique; "
                "the network-wide total overflow is the invariant quantity."
            )
            catchment_data = []
            for cid, c in net.catchments.items():
                demand = c.runoff_m3s(base_scenario.intensity_mm_h)
                ov = fail_res.catchment_overflow_m3s.get(cid, 0.0)
                delivered = demand - ov
                catchment_data.append({
                    "Catchment ID": cid,
                    "Name": c.name,
                    "Inflow Node": c.junction_id,
                    "Area (ha)": c.area_ha,
                    "Demand (m³/s)": round(demand, 3),
                    "Delivered Flow (m³/s)": round(delivered, 3),
                    "Overflow (Shortfall m³/s)": round(ov, 3),
                    "Shortfall %": f"{100 * ov / demand:.1f}%" if demand > 0 else "0.0%",
                })
            st.dataframe(pd.DataFrame(catchment_data), use_container_width=True)
    else:
        st.info("Select one or more drains above to compute failure impacts.")
        m1, m2, m3 = st.columns(3)
        m1.metric("Base Rainfall Demand", f"{base_res.total_demand_m3s:.3f} m³/s")
        m2.metric("Base Deliverable Flow", f"{base_res.max_flow_m3s:.3f} m³/s")
        m3.metric("Base Overflow", f"{base_res.total_overflow_m3s:.3f} m³/s")

    render_drainage_graph_context(graph_net, graph_result, graph_heading)

    # Worst-Case k-Failure Enumeration
    st.markdown("---")
    st.subheader("Automated Combinatorial Worst-Case Analysis")
    if eligible_drains:
        k_val = st.slider("Enumerate Combinations up to Size k:", min_value=1, max_value=min(3, len(eligible_drains)), value=min(2, len(eligible_drains)))

        if st.button("Run Combinatorial Worst-Case Enumeration", type="primary"):
            with st.spinner(f"Evaluating all k-drain failure subsets up to k={k_val}..."):
                sim_summary = enumerate_failures(net, base_scenario, k_max=k_val)

            wc_rows = []
            for k in range(1, k_val + 1):
                wc = sim_summary.worst_case(k)
                if wc:
                    extra = wc.total_overflow_m3s - sim_summary.base_overflow_m3s
                    wc_rows.append({
                        "Failure Size (k)": k,
                        "Total Subsets Evaluated": sim_summary.count(k),
                        "Worst Failure Subset": str(list(wc.failed_drain_ids)),
                        "Post-Failure Flow (m³/s)": round(wc.max_flow_m3s, 4),
                        "Post-Failure Overflow (m³/s)": round(wc.total_overflow_m3s, 4),
                        "Extra Overflow Added (m³/s)": round(extra, 4),
                        "Total Repair Cost": wc.total_repair_cost,
                    })
            st.table(pd.DataFrame(wc_rows))
    else:
        st.info("No drains have positive capacity to fail in this network.")


# ---------------------------------------------------------------------------
# Section D: Repair Optimization
# ---------------------------------------------------------------------------

def render_repair_optimization(net, scenarios) -> None:
    st.header("🔧 Budget-Constrained Repair Optimization")
    st.markdown(
        "Prioritize restoration of degraded drains (`capacity_factor < 1.0`) under budget constraint $B$. "
        "Compares the greedy marginal-gain heuristic with global exhaustive optimization and baseline strategies."
    )

    st.caption(
        "Condition controls below are user-configured simulations, not sensor-detected failures. "
        "All drains are available; candidates are derived immediately from values below 100%."
    )
    configurable = st.multiselect(
        "Drains whose simulated condition you want to change",
        options=sorted(net.drains),
        default=[did for did in sorted(net.drains) if net.drains[did].capacity_factor < 1.0],
    )
    condition_percentages = {
        did: st.slider(
            f"{did} condition (%)",
            min_value=0,
            max_value=100,
            value=int(round(net.drains[did].capacity_factor * 100)),
            key=f"repair_condition_{did}",
        )
        for did in configurable
    }
    configured_net = apply_condition_percentages(net, condition_percentages)
    candidates = _candidate_drains(configured_net)
    if not candidates:
        st.success("All drains are healthy (capacity_factor = 1.0). No repairs needed!")
        no_repair_scenario = scenarios.get("design", next(iter(scenarios.values())))
        context_result = analyze(
            configured_net,
            build_flow_network(configured_net, no_repair_scenario),
            cross_check=False,
        )
        render_drainage_graph_context(
            configured_net,
            context_result,
            "Drainage Network Graph — No Repairs Needed",
        )
        return

    # Scenario & Budget inputs
    c1, c2 = st.columns(2)
    with c1:
        scenario_options = list(scenarios.keys())
        scenario_index = scenario_options.index("design") if "design" in scenario_options else 0
        sc_choice = st.selectbox("Design Scenario", scenario_options, index=scenario_index)
        scenario = scenarios[sc_choice]
    with c2:
        total_cand_cost = sum(configured_net.drains[d].repair_cost for d in candidates)
        budget_max = max(5.0, float(total_cand_cost + 10.0))
        budget = st.slider(
            "Repair Budget (Cost Units):",
            min_value=0.0,
            max_value=budget_max,
            value=min(30.0, budget_max),
            step=5.0,
        )

    # Show Candidate Degraded Drains
    st.subheader(f"Degraded Drain Candidates ({len(candidates)} Drains)")
    cand_data = [
        {
            "Drain ID": did,
            "Type": configured_net.drains[did].kind,
            "From &rarr; To": f"{configured_net.drains[did].from_junction} &rarr; {configured_net.drains[did].to_junction}",
            "Design Cap (m³/s)": configured_net.drains[did].design_capacity_m3s,
            "Operating Factor": f"{configured_net.drains[did].capacity_factor * 100:.0f}%",
            "Effective Cap (m³/s)": configured_net.drains[did].effective_capacity_m3s,
            "Repair Cost (model units)": configured_net.drains[did].repair_cost,
        }
        for did in candidates
    ]
    st.dataframe(pd.DataFrame(cand_data), use_container_width=True)

    # Run Optimization
    st.markdown("---")
    st.subheader("Strategy Comparison & Optimality Gap")

    report = compare_strategies(configured_net, scenario, budget=budget, run_exhaustive=True)

    # Summary Metrics
    opt_plan = report.exhaustive_optimal
    greedy_plan = report.plans.get("greedy")

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Baseline Overflow", f"{report.base_overflow_m3s:.3f} m³/s")
    if greedy_plan:
        m2.metric("Greedy Reduction", f"{greedy_plan.overflow_reduction_m3s:.3f} m³/s", delta=f"Cost: {greedy_plan.total_cost:.1f}")
    if opt_plan:
        m3.metric("Optimal Reduction", f"{opt_plan.overflow_reduction_m3s:.3f} m³/s", delta=f"Cost: {opt_plan.total_cost:.1f}")
        gap = report.gap("greedy")
        gap_str = f"{gap * 100:.1f}%" if gap is not None else "N/A"
        m4.metric("Greedy Optimality Gap", gap_str, delta_color="inverse")
    if report.exhaustive_optimal is None:
        st.warning(
            "The exhaustive search was skipped because the feasible repair search space exceeds its safety limit. "
            "Greedy and baseline results are heuristics; a global optimum and optimality gap are unavailable."
        )

    # Table of all strategies
    strat_rows = []
    for s_name, plan in report.plans.items():
        gap = report.gap(s_name)
        gap_val = f"{gap * 100:.1f}%" if gap is not None else "—"
        strat_rows.append({
            "Strategy": s_name.capitalize(),
            "Drains Repaired": str(list(plan.repaired_drain_ids)),
            "Total Cost": f"{plan.total_cost:.1f} / {budget:.1f}",
            "Overflow Reduction (m³/s)": round(plan.overflow_reduction_m3s, 4),
            "Residual Overflow (m³/s)": round(plan.total_overflow_m3s, 4),
            "Optimality Gap": gap_val,
        })
    st.table(pd.DataFrame(strat_rows))

    # Strategy Chart
    st.pyplot(plot_strategy_comparison(report))

    selected_plan = report.exhaustive_optimal or greedy_plan
    if selected_plan is not None:
        repaired_net = _apply_repairs(configured_net, selected_plan.repaired_drain_ids)
        repaired_ids = selected_plan.repaired_drain_ids
        render_drainage_graph_context(
            repaired_net,
            selected_plan.result,
            "Drainage Graph — Selected Optimized Repair Plan",
            highlight_drain_ids=repaired_ids,
        )

    st.markdown(
        """
        **Algorithmic Insight:**
        - **Greedy Repair:** Iteratively chooses the drain yielding the largest marginal overflow reduction in the
          *current state* that fits within remaining budget. Fast ($O(m \\cdot \\text{maxflow})$), but can be suboptimal
          due to combinatorial path interactions.
        - **Exhaustive Optimization:** Evaluates all $2^n$ feasible candidate subsets. Always achieves the provably
          global optimal allocation, but exhibits exponential runtime growth.
        """
    )


def render_drainage_graph_context(
    net,
    flow_result,
    title: str,
    *,
    highlight_drain_ids=(),
) -> None:
    """Show the shared network graph next to model-result chart sections."""
    st.subheader(title)
    st.caption(
        "Arrows follow modeled drain direction; labels show model flow / effective "
        "capacity (m³/s). Purple edges are scenario minimum-cut bottlenecks. "
        "The network retains its declared provenance."
    )
    fig = plot_offline_drainage_graph(
        net,
        flow_result=flow_result,
        highlight_drain_ids=highlight_drain_ids,
    )
    st.pyplot(fig)


if __name__ == "__main__":
    main()
