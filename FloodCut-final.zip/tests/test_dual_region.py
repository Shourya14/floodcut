from datetime import datetime, timezone
import pytest
from floodcut import rheden, knmi


def mh(guid, coords=None):
    return {'properties': {'OBJECT_GUID':guid}, 'geometry': {'type':'Point', 'coordinates':coords or [6,52]}}


def pipe(oid, a, b):
    return {'properties': {'OBJECTID':oid, 'ID':f'original-{oid}', 'BEGINPUT_ID':a, 'EINDPUT_ID':b},
            'geometry': {'type':'LineString', 'coordinates':[[6,52],[6.1,52.1]]}}


def fixture_network():
    return rheden.build_network([pipe(1,'a','b'),pipe(2,'a','b'),pipe(3,'b','c'),pipe(4,'c','d'),pipe(5,'d','missing')], [mh(x) for x in 'abcd'])


def test_exact_join_parallel_edges_and_unresolved():
    n = fixture_network()
    assert len(n.pipes) == 5 and n.graph.number_of_edges() == 4
    assert n.unresolved == ['5']
    assert n.pipes['1']['properties']['ID'] == 'original-1'
    assert rheden.summary(n.graph)['components'] == 1
    duplicate = rheden.build_network([pipe(1,'a','b')], [mh('a'),mh('a'),mh('b')])
    assert duplicate.unresolved == ['1'] and duplicate.duplicate_manhole_ids == {'a'}


def test_structural_bridges_articulation_and_multiple_failures():
    n = fixture_network()
    bridges, points = rheden.structural_analysis(n.graph)
    assert bridges == {'3','4'} and points == {'b','c'}
    after, separated = rheden.simulate_failure(n.graph, ['3','4'])
    assert rheden.summary(after)['components'] == 3
    assert separated == {'c','d'}
    assert n.graph.number_of_edges() == 4
    with pytest.raises(ValueError): rheden.simulate_failure(n.graph, ['5'])


def test_knmi_missing_trace_and_hour_24():
    text = '# STN,YYYYMMDD,HH,RH\n275,20240101,23,-1\n275,20240101,24, 4\n275,20240102,1,\n'
    start=datetime(2024,1,1,23,tzinfo=timezone.utc); end=datetime(2024,1,2,2,tzinfo=timezone.utc)
    rows=knmi.parse_hourly(text,start,end)
    assert rows[0]['trace'] and rows[0]['rain_mm'] is None and not rows[0]['missing']
    assert rows[1]['rain_mm'] == .4
    assert rows[2]['missing'] and rows[3]['missing']


def test_fetch_detects_incomplete_batches(monkeypatch):
    def query(service, params):
        return {'objectIds':[1,2]} if params.get('returnIdsOnly') else {'features':[pipe(1,'a','b')]}
    monkeypatch.setattr(rheden,'_query',query)
    with pytest.raises(RuntimeError, match='Incomplete'): rheden.fetch_layer('pipes')


def test_region_switching_and_algorithm_gating(monkeypatch):
    from streamlit.testing.v1 import AppTest
    import floodcut.ui.rheden as ui
    monkeypatch.setattr(ui,'load_network',lambda: fixture_network())
    from pathlib import Path
    app=AppTest.from_file(Path(__file__).resolve().parents[1] / 'src/floodcut/app.py', default_timeout=30).run()
    assert not app.exception
    app.sidebar.radio[0].set_value('Rheden 🇳🇱').run()
    assert not app.exception
    assert any('Hydraulic maximum flow' in x.value for x in app.markdown)
    assert any('Rheden' in x.value for x in app.header)
    app.multiselect[0].set_value(['3', '4']).run()
    assert not app.exception
    assert any('2 manholes are in sections' in x.value for x in app.caption)
    next(b for b in app.button if b.label == 'Reset scenario').click().run()
    assert not app.exception and app.multiselect[0].value == []
    app.sidebar.radio[0].set_value('Mumbai 🇮🇳').run()
    assert not app.exception
    assert any('Mumbai' in x.value for x in app.header)
