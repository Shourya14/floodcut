# FloodCut: Mumbai Flood Risk & Drainage Optimization

A Discrete Mathematics project: model a drainage network as a directed capacitated graph, find bottlenecks with
Max-Flow Min-Cut, analyse combinations of drain failures, and choose repairs under a budget.

**Status: Phase 7 (Testing and Final Audit) complete.** The complete 7-phase roadmap is fully implemented,
verified by 296 automated offline unit and integration tests, and mathematically audited for flow conservation,
capacity bounds, and min-cut duality.

> **Academic Prototype Notice:** The IMD rainfall data in `data/real/` is a real observed dataset (1901–2021).
> The drainage network geometry and capacities in `data/simulated/` are **SYNTHETIC** testbed models.
> Results from this project describe a prototype capacity-screening model, not Mumbai's real flood risk.
> See `docs/PHASE5_DATA_INTEGRATION.md#known-limitations`.

---

## Discrete Mathematics Syllabus Alignment

FloodCut directly maps core syllabus concepts to working, tested software:

- **Graph Theory:** Directed capacitated networks $G = (V, E, c)$, vertices, confluences, and flow conservation.
- **Max-Flow Min-Cut Theorem:** Edmonds–Karp residual graph augmentations and bottleneck identification.
- **Combinatorics:** Combinatorial failure enumeration across $\binom{m}{k}$ subsets.
- **Set Theory:** Cut partitions $(S, T)$ and feasible repair subset lattices.
- **Combinatorial Optimization:** Budget-constrained network-capacity improvement. Repair benefits interact, so this is not generally a standard additive-value 0-1 knapsack problem.
- **Algorithm Analysis:** Marginal-gain Greedy heuristic ($O(m \cdot T_{\text{flow}})$) vs global Exhaustive search ($O(2^n \cdot T_{\text{flow}})$) with optimality gap quantification.

👉 **Full Mathematical Write-up:** See [`docs/DISCRETE_MATH_ALIGNMENT.md`](docs/DISCRETE_MATH_ALIGNMENT.md).

---

## Setup & Reproduction Instructions (Python 3.10+)

### 1. Environment Setup

```bash
# Create and activate virtual environment
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
pip install -e .
```

### 2. Run Validation & Tests

```bash
# 1. Validate the drainage network data
floodcut validate

# 2. Run the complete automated test suite (296 tests, ~10s runtime offline)
pytest -v
```

### 3. Launch the Interactive Dashboard

Launch the Streamlit web dashboard locally:

```bash
floodcut app                       # launches on http://localhost:8501
floodcut app --port 8502           # custom port
floodcut dashboard                 # alias for app
```

Or run Streamlit directly:

```bash
streamlit run src/floodcut/app.py
```

---

## Dashboard Walkthrough

1. **Interactive Map:** Leaflet/Folium pan-zoom map displaying IMD rainfall-grid context (`REAL:IMD_GRID`), derived waterlogging hotspot points (`DERIVED:GEOCODED`), and synthetic drain conduits (`SYNTHETIC`). Includes an offline graph fallback.
2. **Rainfall Explorer:** Historical IMD monthly rainfall observations (1901–2021), annual and monsoon trends, and monthly breakdown charts. These monthly observations are not storm-scale peak intensities.
3. **Failure Simulation:** Select blocked drains, recompute max flow and total overflow shortfall, inspect the model's catchment allocation, and enumerate worst-case combinations of drain failures.
4. **Repair Optimization:** Inspect degraded drains, set a repair budget, compare marginal-gain greedy and exhaustive optimization with baseline strategies, and inspect the resulting graph.

---

## Command-Line Interface (CLI)

```bash
floodcut validate                          # validate network JSON data
floodcut info                              # counts, DAG check, parallel drains, degraded drains
floodcut demand --scenario design          # rainfall demand per catchment (50 mm/h)
floodcut demand --scenario extreme         # 100 mm/h with high tide
floodcut maxflow --scenario design         # max flow, min cut, overflow (Phase 2 engine)
floodcut maxflow --scenario extreme --no-cross-check   # skip NetworkX cross-check
floodcut failure -k 2 --scenario design    # 2-drain failure simulation
floodcut repair --budget 50 --scenario design   # repair optimisation
floodcut app                               # start web dashboard
python -m floodcut info                    # same, without console script
```

---

## Data Provenance Architecture

| Directory / File | Provenance Label | Description |
|---|---|---|
| `data/real/imd_mumbai_monthly_rainfall_1901_2021.csv` | `REAL:IMD_GRID` | 121 years of monthly observations from IMD via OpenCity India |
| `src/floodcut/geo_loader.py` (IMD Grid Point) | `REAL:IMD_GRID` | IMD 0.25° grid cell centre ($19.00^\circ\text{ N}, 72.75^\circ\text{ E}$) |
| `src/floodcut/geo_loader.py` (Hotspots) | `DERIVED:GEOCODED` | 7 waterlogging junctions geocoded from MCGM civic reports |
| `data/simulated/mumbai_sim_network.json` | `SYNTHETIC` | 14-junction, 14-drain illustrative benchmark network |
| `data/simulated/rainfall_scenarios.json` | `SYNTHETIC` | Benchmark storm intensities & tide factors |

---

## Repository Layout

```
src/floodcut/
  app.py                         # Streamlit interactive web dashboard (Phase 6)
  ui/                            # UI helper modules (Phase 6)
    map_view.py                  # Folium map & offline graph
    charts.py                    # Matplotlib visualizers
    state.py                     # Cached data loaders
  models.py                      # Immutable domain dataclasses with scalar validation
  hydrology.py                   # Rational method demand calculation Q = C*i*A/360
  io.py                          # JSON network & scenario I/O
  validation.py                  # Relational cross-record validation
  graph.py                       # Physical MultiDiGraph & FlowNetwork (S*, T*)
  maxflow.py                     # Edmonds–Karp max-flow & min-cut engine
  failure.py                     # Combinatorial k-failure enumeration
  repair.py                      # Greedy, exhaustive, & baseline repair optimization
  cli.py                         # Command-line interface
  provenance.py                  # Data provenance labels & metadata
  rainfall_loader.py             # IMD monthly rainfall CSV loading & unit conversion
  geo_loader.py                  # Geospatial points loading & validation
data/
  simulated/                     # Synthetic testbed datasets
  real/                          # Real IMD observational datasets
tests/                           # 276 automated offline tests
docs/
  ARCHITECTURE.md                # System layers & design decisions
  ROADMAP.md                     # Completed 7-phase roadmap
  ASSUMPTIONS.md                 # 10 modeling assumptions & limitations
  MAXFLOW.md                     # Max-flow formulas, proofs & worked examples
  PHASE5_DATA_INTEGRATION.md     # Data sources, units, & provenance
  PHASE6_FRONTEND.md             # Dashboard architecture & setup
  DISCRETE_MATH_ALIGNMENT.md     # Discrete Mathematics syllabus mapping
```

---

## Troubleshooting & Known Limitations

1. **CartoDB Basemap Warning:** If Folium issues a warning regarding CartoDB tiles, the map has been preconfigured to use OpenStreetMap (`OpenStreetMap`) tiles without requiring an API key.
2. **Windows Terminal CP1252:** All CLI outputs use ASCII arrows (`->`) to ensure clean execution across Windows Command Prompt and PowerShell without encoding errors.
3. **Monthly Rainfall Disaggregation:** Monthly rainfall accumulated millimetres (mm) converted to mean hourly intensity (mm/h) produces a time-averaged rate, NOT a peak design-storm intensity. Use scenario intensities (e.g., 50 mm/h) for flood capacity screening.
4. **Offline Tests:** The entire test suite (`pytest`) is designed to run offline without internet connectivity.

## Dual-region recovery: Mumbai and Rheden

Run from the project root using Python 3.10 or later:

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows: .venv\Scripts\activate
pip install -e ".[dev,ui]"
streamlit run src/floodcut/app.py
python -m pytest -q
```

Choose a region in the sidebar. Mumbai retains the original **synthetic**
drainage model and **real** IMD monthly rainfall observations. Its flow, cut,
failure and repair results are model screening results, not BMC infrastructure
or operational flood forecasts.

Rheden retrieves the [municipal gravity-sewer pipe service](https://www.arcgis.com/home/item.html?id=5751bc93d79c4cf9b7b4f583caabc550)
and [municipal manhole service](https://www.arcgis.com/home/item.html?id=06520cc351ff41058fda33599cc2f99c)
on demand. An internet connection is required; the first load makes multiple
bounded requests and can take time. The two municipal item pages did not state
redistribution terms when inspected, so the records are not bundled. The app
caches them in memory for up to 24 hours; rerun later to refresh. Service data
can change or be unavailable. A transfer is rejected if the fetched object IDs
are incomplete. Source item metadata is from 2021 and is not proof that every
record reflects current infrastructure. Data © Municipality of Rheden; consult
the source item pages for current terms.

The derived graph joins each pipe's `BEGINPUT_ID` and `EINDPUT_ID` exactly to
unique manhole `OBJECT_GUID` values with valid geometry. Pipe `OBJECTID` is the
selection key; the original attributes and IDs remain available in the
inspector. Null, unmatched, duplicate or invalid endpoints leave the pipe out
of the graph. Valid geometry counts and graph edge counts are distinct; a
match does not imply a connected network. All connected components are retained,
including parallel pipes and loops. The graph is **undirected** and incomplete;
structural bridges, articulation points, failure simulation and rankings are
topological only. The smaller-side bridge ranking and separated-section rule
make no claims about service, outlets, hydraulics or flooding. When failure
splits a pre-existing component, the largest remainder is used as a reference;
equal sizes are broken deterministically. All statistics use all fetched data;
the map reports its display limit and overlays selections and affected pipes.
Select pipes or manholes by their source identifiers to inspect attributes and
connections. Select multiple graph pipes to simulate removals and use Reset to
restore the baseline.

Rheden hydraulic max flow, hydraulic min cut, and financial repair optimization
are intentionally unavailable: pipe diameter and invert-level units, datum and
engineering meaning, capacities, directions, and repair costs have not been
verified. No hydraulic predictions are derived from geometry.

The optional rainfall tab requests [KNMI hourly observations](https://www.daggegevens.knmi.nl/klimatologie/uurgegevens)
for station 275, Deelen Airport, outside Rheden. Timestamps are UTC hour-ending;
RH values are tenths of a millimetre, `-1` is a trace below 0.05 mm, and blank
or absent hours are missing. Trace and missing values remain distinct and are
not plotted as zero. The table lists every requested hour; a warning appears if
the most recent observation is over 48 hours old. Station observations do not
represent local measurements at every pipe. KNMI observations and the municipal
network are independent; they do not form a calibrated hydraulic model.
