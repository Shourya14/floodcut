# Dual-region implementation and data boundaries

## Mumbai

Mumbai uses the bundled synthetic drainage testbed and the preserved IMD
monthly observations for 1901–2021. The unified map control independently
toggles drainage edges, network nodes, junctions, outfalls, catchment allocation
points, derived waterlogging locations, and the IMD rainfall reference. No
catchment polygons are drawn because the dataset contains areas and inlet IDs,
not boundary geometry.

Failure simulation accepts independent 0–100% loss values for any number of
drains. Remaining capacity is the current effective capacity multiplied by
`1 - failure_percentage / 100`. A user-set rainfall intensity immediately
rebuilds runoff demand, the flow network, maximum flow, minimum cut, overflow,
and charts. These values are simulations, not detected failures or forecasts.

Repair analysis exposes every drain for user-configured 0–100% condition
values. Candidates are derived dynamically from all drains below 100%, with no
fixed four-drain list. The six existing strategies remain Greedy, Severity,
Cheapest, Benefit-to-Cost Ratio, Random, and Exhaustive (subject to the existing
bounded-search safety limit). Bundled repair costs remain abstract model units;
they are not relabelled as INR because no verified rupee cost model is present.

## Rheden

Rheden preserves the municipal ArcGIS pipe and manhole records and the KNMI
Deelen hourly-observation integration. The municipal graph supports record
inspection, structural bridge/articulation analysis, multiple-pipe removal,
and affected-section highlighting.

Hydraulic maximum flow, hydraulic minimum cut, rainfall-runoff coupling, and
financial repair optimisation remain intentionally unavailable for Rheden.
The available municipal fields have not established verified capacity units,
flow directions, outfalls, invert datum/meaning, catchments, or repair costs.
Creating these values would violate the project's data-integrity requirements.
Deelen observations are outside Rheden and are not a calibrated input to the
municipal network.

## Rainfall coverage

The bundled IMD record ends in 2021. No unverified values have been appended for
2022–2025. KNMI hourly observations are fetched on demand with missing and trace
hours preserved. Historical observations, user-configured simulation inputs,
and model outputs remain separately labelled.

## Verification

The recovered archive began with 284 passing tests. The dynamic partial-failure
and condition controls add 12 focused tests, for 296 passing tests in this
delivery. Streamlit smoke tests cover both region routes. The previously
reported 299-test workspace was not available, so this delivery does not claim
to reproduce three unavailable tests or unverified changes from that workspace.
